import scipy.stats, numpy as np, sys

c = int(sys.argv[2]) if len(sys.argv) > 2 else 1

seedgen = np.random.RandomState()



n_subclusters = 1 # how many jobs are executed in parallel?
n_cores_per_subcluster = 4 # how many threads/subsets does each job have?
reassign = False # if no more jobs are to be done, should subclusters make their threads available to other subclusters? causes segfaults sometimes. don't try if not sure
jobs = [{
    'seed': seedgen.randint(0, np.iinfo(np.int32).max),
    'cores': n_cores_per_subcluster,
    'pars': {
        'msac':    {'lb':   1.5, 'ub':   3.5, 'prop_sd':  0.1},
        'refix':   {'lb':   0.2, 'ub':   1.8, 'prop_sd':  0.1},
        'delta0':  {'lb':   4.0, 'ub':  15.0, 'prop_sd':  0.5},
        'eta':     {'lb':   0.01, 'ub':  1.0, 'prop_sd':  0.05}
        },
    'fixseq': 'PB2expVP%d' % (PP),  
    'corpus': 'PB2',
    'chain': chain,
    'iter': 10,
    'path': '../DATA',
    'outfile' : 'PP%d_%d.dat' % (PP, chain),
    } for PP in xrange(1,35) for chain in xrange(1,3)]

jobs = jobs[c-1:c]

def prior(theta, pmean, psd, logpfac, **more_args):
    return np.sum(scipy.stats.norm.logpdf(theta, pmean, psd) + logpfac)

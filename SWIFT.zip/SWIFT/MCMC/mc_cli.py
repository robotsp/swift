import numpy as np
from Queue import Queue, Empty
import warnings, scipy.stats, threading, traceback, time, sys, hashlib, os, thread, pickle


### def jobs
if len(sys.argv) > 1:
    jobfile = sys.argv[1]
else:
    raise ValueError("No jobfile specified.")

exec("from jobs_%s import n_subclusters, n_cores_per_subcluster, reassign, jobs, prior" % jobfile)

### end def jobs

n_logliks = 3

def nearPD(x, corr=False, keepDiag=False, do2eigen=True, doSym=False, doDykstra=True, onlyValues=False, onlyMatrix=False, ensureSymmetry=None, eig_tol=1e-6, conv_tol=1e-7, posd_tol=1e-8, maxit=100, conv_norm_type=np.inf, trace=False):
    '''
    Maximilian M. Rabe, 2018
    GPL v3 licence

    Compute the nearest positive definite matrix to an approximate one, typically a correlation or variance-covariance matrix.

    This is a Python port of the Matrix::nearPD function in R (Bates & Maechler, 2017)

    Arguments are identical with exception of additional (but optional) onlyMatrix and conv_norm_type:

    x               numeric n * n approximately positive definite matrix, typically an approximation to a correlation or covariance matrix. If x is not symmetric (and ensureSymmetry is not false), symmpart(x) is used.
    corr            logical indicating if the matrix should be a correlation matrix.
    keepDiag        logical, generalizing corr: if TRUE, the resulting matrix should have the same diagonal (diag(x)) as the input matrix.
    do2eigen        logical indicating if a posdefify() eigen step should be applied to the result of the Higham algorithm.
    doSym           logical indicating if X <- (X + t(X))/2 should be done, after X <- tcrossprod(Qd, Q); some doubt if this is necessary.
    doDykstra       logical indicating if Dykstra's correction should be used; true by default. If false, the algorithm is basically the direct fixpoint iteration Y(k) = P_U(P_S(Y(k-1))).
    onlyValues      logical; if True, the result is just the vector of eigen values of the approximating matrix.
    onlyMatrix      logical; if True, the result is just the approximating matrix. Cannot be True if onlyValue is True.
    ensureSymmetry  logical; by default, symmpart(x) is used whenever isSymmetric(x) is not true. The user can explicitly set this to TRUE or FALSE, saving the symmetry test. Beware however that setting it FALSE for an asymmetric input x, is typically nonsense!
    eig_tol         defines relative positiveness of eigenvalues compared to largest one, lambda_1. Eigen values lambda_k are treated as if zero when lambda_k / lambda_1 <= eig_tol.
    conv_tol        convergence tolerance for Higham algorithm.
    posd_tol        tolerance for enforcing positive definiteness (in the final posdefify step when do2eigen is TRUE).
    maxit           maximum number of iterations allowed.
    conv_norm_type  convergence norm type (norm(*, type)) used for Higham algorithm. The default is np.inf (infinity), for reasons of speed (and back compatibility); using "fro" is more in line with Higham's proposal.
    trace           logical or integer specifying if convergence monitoring should be traced.

    '''
    if onlyValues and onlyMatrix:
        raise ValueError("Only one of onlyValues or onlyMatrix may be True.")
    if ensureSymmetry is None and not np.allclose(x, x.T):
        ensureSymmetry = True
    if ensureSymmetry:
        x = (x + x.T) / 2
    n = x.shape[1]
    if keepDiag:
        diagX0 = np.diag(x)
    if doDykstra:
        D_S = np.asmatrix(np.copy(x))
        D_S[:] = 0
    X = np.asmatrix(np.copy(x))
    it = 0
    converged = False
    conv = np.inf
    while it < maxit and not converged:
        Y = np.asmatrix(np.copy(X))
        if doDykstra:
            R = Y - D_S
        d, Q = np.linalg.eigh(R if doDykstra else Y, UPLO='L')
        p = d > eig_tol * d[-1]
        if not np.any(p):
            raise ValueError("Matrix seems negative semi-definite")
        Q = Q[:, p]
        X = np.dot(np.multiply(Q, d[p]), Q.T)
        if doDykstra:
            D_S = X - R
        if doSym:
            X = (X + X.T) / 2
        if corr:
            np.fill_diagonal(X, 1)
        elif keepDiag:
            np.fill_diagonal(X, diagX0)
        conv = np.linalg.norm(Y - X, ord=conv_norm_type) / np.linalg.norm(Y, ord=conv_norm_type)
        it += 1
        if trace:
            print "iter %3d : #{p}=%d, ||Y-X|| / ||Y||= %11g" % (it, np.sum(p), conv)
        converged = conv <= conv_tol
    if not converged:
        print("nearPD did not converge in %d iterations" % it)
    if do2eigen or onlyValues:
        d, Q = np.linalg.eigh(X, UPLO='L')
        Eps = posd_tol * np.abs(d[-1])
        if d[0] < Eps:
            d[d < Eps] = Eps
            if not onlyValues:
                o_diag = np.diag(X)
                X = Q.dot(np.multiply(Q, d).T)
                D = np.sqrt(np.maximum(Eps, o_diag) / np.diag(X))
                X[:] = np.multiply(np.multiply(D, X).T, D).T
        if onlyValues:
            return d
        if corr:
            np.fill_diagonal(X, 1)
        elif keepDiag:
            np.fill_diagonal(X, diagX0)
    if onlyMatrix:
        return X
    else:
        return {'mat': X, 'eigenvalues': d[::-1], 'normF': np.linalg.norm(x - X, ord='fro'), 'corr': corr, 'iterations': it, 'rel.tol': conv, 'converged': converged}


def sample(likelihood, prior, params, num_samples, samples=None, random=None, initial_shape_mat=None, initial_like=None, skip_it=0, output=None, output_state=None, output_state_interval=1, shape_mat=None, prop_sd=None, fixed_params_ind=[], accept_mean=0.234, gamma=2. / 3, **more_args):
    """This function generate samples from the distribution over the hyperparameters using
    the MH method.

    :param likelihood: Function which accepts an array of parameters as a first parameter and all of the additional parameters (more_args)
    :param prior: Prior function which accepts an array of parameters and returns a single prior log-likelihood
    :param num_samples: Number of requested iterations
    :param random: Either a numpy RandomState object, a log or int seed. If None (default), numpy's internal default random number generator (np.random) is used.
    :param initial_shape_mat: An initial shape matrix. If None, determined by means of prop_sd or parameter identity matrix.
    :param initial_like: An initial log-likelihood (useful if continuing previously aborted chain)
    :param skip_it: Number of iterations to skip (useful if continuing previously aborted chain)
    :param output: A file or csv writer to which to output results. If None (default), output is written into stdout.
    :param prop_sd: If shape_mat is None, it is determined from given proposal SDs.
    :param fixed_params_ind: Which parameters (indices) are fixed and should not be varied?
    :param accept_mean: Coerced acceptance rate.
    :param gamma: Gamma.
    :param more_args: Additional keyword argument to be passed as additional arguments to the likelihood function.
    :return: accepted samples, number of iterations completed, acceptance rate, most recent shape matrix
    """

    if isinstance(random, (long, int)):
        random = np.random.RandomState(random)
    elif type(random) is not np.random.mtrand.RandomState:
        raise ValueError("random must be None, long, int or numpy.RandomState!")

    fixed_param_num = len(fixed_params_ind)
    num_params = params.shape[0]
    unfixed_params_num = num_params - fixed_param_num
    unfixed_param_ind = list(set(np.arange(0, num_params)) - set(fixed_params_ind))

    # import ipdb; ipdb.set_trace()
    if samples is None:
        samples = np.empty((unfixed_params_num, int(num_samples)))

    if initial_shape_mat is None:
        if prop_sd is None:
            covMat = np.identity(unfixed_params_num)
        else:
            covMat = np.diag(prop_sd**2)

        # shape_mat = np.linalg.cholesky(2.4 ** 2 / unfixed_params_num * covMat)
        shape_mat = np.linalg.cholesky(covMat)
    else:
        shape_mat = np.copy(initial_shape_mat)
        print "Starting with initial shape matrix", shape_mat

    oldparams = np.copy(params)

    theta = np.copy(params)[unfixed_param_ind]

    if initial_like is None:
        l_old = likelihood_cli(params, **more_args)
    else:
        l_old = np.copy(initial_like)
        print "Starting with initial likelihood", initial_like

    assert type(l_old) is np.ndarray and len(l_old.shape) == 1, "Return value of likelihood function must be one-dimensional numpy array"

    n_logliks = l_old.shape[0]

    if np.any(np.isinf(l_old)):
        raise ValueError("Log-likelihood of initial proposal is -inf! Out of bounds!?")

    rejected_num = 0

    if not type(skip_it) is int or skip_it < 0:
        print "skip_it must be integer greater than or equal to 0"
    elif skip_it > 0:
        print "Skipping first", skip_it, "iterations."

    for i in xrange(skip_it, num_samples):
        # print(i)

        rand_vec = random.randn(unfixed_params_num)
        theta_prop = theta + np.dot(shape_mat, rand_vec)

        params[unfixed_param_ind] = theta_prop
        l_new = likelihood_cli(params, **more_args)
        assert l_new.shape == (n_logliks, )
        if not np.any(np.isinf(l_new)) and i > 0:
            # new likelihood was okay and we need to re-evaluate the old likelihood
            oldparams = np.copy(params)
            oldparams[unfixed_param_ind] = theta  # theta still contains the last accepted parameter set
            l_old = likelihood_cli(oldparams, **more_args)
            assert l_old.shape == (n_logliks, )
        warnings.filterwarnings("default")

        accept = min(1, np.exp(l_new[0] + prior(theta_prop, **more_args) - l_old[0] - prior(theta, **more_args)))

        if accept >= 1.0 or random.rand() < accept:
            theta = theta_prop
            l_old = l_new
        else:
            rejected_num += 1

        samples[:, i] = theta[:]

        line = (theta, l_old, l_new)
        if type(output) == file:
            # is file?
            output.write(','.join(np.array(np.concatenate(line), 'str')) + "\n")
            output.flush()
        elif callable(output):
            # is callable?
            output(*line)
        else:
            try:
                # is CSVWriter?
                output.writerow(np.concatenate(line))
            except AttributeError:
                print line

        eta = unfixed_params_num * (i + 1)**-gamma
        M = np.dot(shape_mat, np.dot(
            np.identity(unfixed_params_num) + eta * (accept - accept_mean) / (np.linalg.norm(
                rand_vec) ** 2) * np.outer(rand_vec, rand_vec), shape_mat.T))
        eig = np.linalg.eigvalsh(M)
        tol = M.shape[1] * np.max(np.abs(eig)) * np.finfo(float).eps
        if not np.allclose(M, M.T) or np.any(np.iscomplex(eig)) or np.any(np.real(eig) < tol):
            print "M not PD!"
            M = np.asarray(nearPD(M, onlyMatrix=True))
        shape_mat = np.linalg.cholesky(M)

        if (not (i + 1) % output_state_interval or i == num_samples - 1) and not output_state is None:
            state = more_args.copy()
            state.update({'skip_it': i + 1, 'initial_shape_mat': shape_mat, 'initial_like': l_old, 'params': oldparams, 'random': random, 'prior': prior, 'num_samples': num_samples})
            if callable(output_state):
                output_state(state)
            else:
                output_state.seek(0)
                output_state.truncate()
                pickle.dump(state, output_state, 2)
                output_state.flush()
            print 'Dumped state after', i + 1, 'iterations'

    # print '**** CHAIN COMPLETE. ACCEPTANCE RATE: %.1f%% ****' % (100.-100.*rejected_num/num_samples)
    # return samples, i, 100.-100.*rejected_num/num_samples, shape_mat


def likelihood_cli(params, pmin, pmax, pname, subcluster, **more_args):
    # evaluate the likelihood using the comand like interface of SWIFT
    if np.any(params < pmin) or np.any(params > pmax):
        pars_out_of_bounds = np.logical_or(params < pmin, params > pmax)
        print 'Proposal out of bounds for', pname[pars_out_of_bounds], ':', params[pars_out_of_bounds]
        return np.repeat(-np.inf, n_logliks)

    parstr = ""
    for i in xrange(len(params)):
        parstr = "%s%s=%f" % (parstr, pname[i], params[i])
        if not (i == (len(params) - 1)):
            parstr = "%s," % (parstr)
    command = "./swiftstatp -t 2 -c %s -s %s -f -P %s" % (subcluster['job']['corpus'], subcluster['job']['fixseq'], parstr)
    os.chdir("../SIM")
    results = os.popen(command).read()  # evaluate SWIFT
    results = results.split("\n")[-2].replace(":", ",").split(", ")[1:]  # extract likelihood values from output-string of SWIFT-cli
    return np.array(results, 'd')

def do_job(subcluster):
    job = subcluster['job']
    random = np.random.RandomState(job['seed'])
    subcluster['random'] = random
    pname = np.array(job['pars'].keys(), 'str')
    pmin  = np.array([job['pars'][par].get('lb', -np.inf) for par in pname], 'd')
    pmax  = np.array([job['pars'][par].get('ub', np.inf) for par in pname], 'd')
    prop_sd  = np.array([job['pars'][par].get('prop_sd', 1.0) for par in pname], 'd')
    pmean = (pmax-pmin)/2+pmin
    psd = pmax-pmin
    logpfac = np.log(1/ (scipy.stats.norm.cdf(pmax, pmean, psd) - scipy.stats.norm.cdf(pmin, pmean, psd)))

    outfile = job['outfile'] if not callable(job['outfile']) else job['outfile'](job)

    statefile = outfile + '.state'

    try:
        # try to open statefile, outfile and read state from statefile
        sf = open(statefile, "r+b")
        of = open(outfile, "r+")
        state = pickle.load(sf)
    except:
        # if any of these fails (nothing to be continued), just start from scratch (iteration 0)
        sf = open(statefile, "wb")
        of = open(outfile, "w")
        state = None


    def save_sampling_state(state):
        sf.truncate(0)
        sf.seek(0)
        # state['swift_seed'] = swift.getmodel(model=subcluster['model'], field="seed")
        del state['subcluster']
        pickle.dump(state, sf, 2)
        sf.flush()

    output_state_interval = 10

    if not state is None:

        print 'State file', statefile, 'was detected with current state:', state

        # outfile should have skip_it+1 lines (incl. header)
        for i in xrange(state['skip_it']+1):
            of.readline()
        print "Truncate",outfile,"after",i,"lines."
        of.truncate()

        init_subcluster(subcluster, seed=state['swift_seed'])

        if state.get('num_samples', 0) < job['iter']:
            state['num_samples'] = job['iter']

        del state['swift_seed']

        sample(
            likelihood=likelihood_cli,
            output=of,
            output_state=save_sampling_state,
            output_state_interval=output_state_interval,
            subcluster=subcluster,
            **state)

    else:

        of.write(','.join(np.concatenate((pname, ['x_LL'], ['x_LL%d' % (i+1) for i in xrange(n_logliks-1)], ['y_LL'], ['y_LL%d' % (i+1) for i in xrange(n_logliks-1)])))+'\n')

        init_subcluster(subcluster)

        pinit = random.uniform(pmin, pmax)

        sample(
            likelihood=likelihood_cli,
            prop_sd=prop_sd,
            prior=prior,
            params=pinit,
            pmin=pmin,
            pmax=pmax,
            pname=pname,
            pmean=pmean,
            psd=psd,
            logpfac=logpfac,
            num_samples=job['iter'],
            random=random,
            output=of,
            output_state=save_sampling_state,
            output_state_interval=output_state_interval,
            subcluster=subcluster)

    free_subcluster(subcluster)

    try:
        of.close()
        sf.close()
    except:
        print "Could not close outfile and/or statefile"


# def free_subcluster(subcluster):
    # if 'model' in subcluster:
        # swift.freemodel(model=subcluster['model'])
    # if 'data' in subcluster:
        # swift.freedata(data=subcluster['data'])

def init_subcluster(subcluster, seed=None):
    job = subcluster['job']
    verbose = False
    # cdata = swift.loaddata("%s/fixseqin_%s.dat" % (job['path'],job['fixseq']), verbose=verbose)
    # if subcluster['threads'] > 1:
        # subcluster['data'] = swift.subsetdata(data=cdata, subsets=subcluster['threads'], verbose=verbose)
        # swift.freedata(cdata)
    # else:
    #     subcluster['data'] = cdata
    #print 'Subsets:',[swift.getdata(data=subcluster['data'], subset=i)[0:2] for i in xrange(subcluster['threads'])]
    # subcluster['model'] = swift.loadmodel(outputPath=job['path'], parmPath="%s/swpar_%s_%s.par" % (job['path'], job['corpus'], job['fixseq']), corpusFile="%s/corpus_%s.dat" % (job['path'], job['corpus']), expdatName="%s/ExpDat_%s.dat" % (job['path'], job['corpus']), seed=subcluster['random'].randint(np.iinfo(np.int32).min, np.iinfo(np.int32).max) if seed is None else seed, verbose=verbose)


def queue_consumer_nonblocking(subcluster_nr):
    subcluster = subclusters[subcluster_nr-1]
    try:
        while True:
            job = q.get_nowait()
            subcluster['job'] = job
            print 'Subcluster %d is assigned new job:' % (subcluster_nr), job
            try:
                do_job(subcluster)
            except KeyboardInterrupt:
                print 'KeyboardInterrupt'
                exit(1)
            except:
                traceback.print_exc()
            q.task_done()
    except Empty:
        subcluster['active'] = False
        print 'Subcluster %d shutting down because there are no more jobs.' % (subcluster_nr)
        active_subcls = [subclusters[i] for i in np.where([s['active'] for s in subclusters])[0]]
        if active_subcls and reassign:
            subclusters_cores = np.array([s['threads'] for s in active_subcls], 'i')
            cores_to_add = np.array(np.ceil(float(np.sum(subclusters_cores) + subcluster['threads'])/len(active_subcls)) - subclusters_cores, 'i')
            cores_to_add[-1] = subcluster['threads'] - np.sum(cores_to_add[:-1])
            for i in xrange(len(active_subcls)):
                print cores_to_add[i],'threads are reassigned to subcluster',active_subcls[i]['id'],'(previously', active_subcls[i]['threads'],', now',active_subcls[i]['threads']+cores_to_add[i],'threads)',
                if not cores_to_add[i]:
                    continue
                free_subcluster(active_subcls[i])
                active_subcls[i]['threads'] += cores_to_add[i]
                init_subcluster(active_subcls[i])
        else:
            print 'Threads are not reassigned.'
        pass


q = Queue()


subclusters = [{'id':i, 'threads':n_cores_per_subcluster, 'active': True} for i in xrange(n_subclusters)]


for i in xrange(len(jobs)):
    j = jobs[i].copy()
    j['hash'] = hashlib.md5(str(j)).hexdigest()
    j['id'] = i+1
    q.put_nowait(j)

workers = []

for i in xrange(n_subclusters-1):
    t=threading.Thread(target=queue_consumer_nonblocking, args=(i+2,))
    workers.append(t)
    t.daemon = True # do not keep Python alive for this thread
    t.start()

print 'Pass on to foreground thread for subcluster #1...'
queue_consumer_nonblocking(1)
q.join()
print 'All jobs are done.'
exit(0)

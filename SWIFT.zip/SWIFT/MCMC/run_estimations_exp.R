#rm(list=ls())
library(parallel)
library(pbmcapply)

file_jobfile <- "job_PB2exp.py" # estimate parameters for the experimental data

N_chains = 10

start_estimation <- function(job) {
  command = paste("python2", job$callfile, job$jobfile, job$chainID)
  print(command)
  system(command, wait = T)
}

jobs <- expand.grid(callfile = "mc_cli.py", 
                    jobfile = file_jobfile, 
                    chainID = c(1:N_chains))
jobs <- split(jobs, seq(nrow(jobs)))


Ncores <- detectCores()
pbmclapply(X = jobs, 
           FUN = start_estimation, 
           mc.cores = Ncores)

#!/bin/bash
#PBS -N PB2exp
#PBS -m abe
#PBS -j oe
#PBS -l ncpus=4
#PBS -l nodes=1:ppn=4
#PBS -l walltime=128:00:00
#PBS -l mem=1g
#PBS -t 1-170

python2 --version

LOGFILE=$PBS_O_WORKDIR/${PBS_JOBID}.log
NUMPROCS=`wc -l < $PBS_NODEFILE` 

export OMP_NUM_THREADS=$NUMPROCS

# this will load jobs from jobs_PB2model.py
python2 mc_cli.py PB2model $PBS_ARRAYID

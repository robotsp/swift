/*--------------------------------------------
    Likelihood-Evaluation of SWIFT III
    generative mode also works, but not parallel

    Note: To use multithreading, compile with
    -fopenmp for OpenMP or -pthread for POSIX
    thread (typically enabled by default). To
    explicitly disable multithreading, compile
    with -DDISABLE_THREADS.

 =========================================
 (Version 1.0, 26-AUG-02)    
 (Version 2.0, 23-JUN-03)
 (Version 3.0, 10-DEC-03)
 (Version 4.0, 25-JUN-04)
 (Version 4.1, 19-MAY-07)
 (Version 5.0, 07-OCT-11)
 ----------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <sys/time.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/ioctl.h>
#include <ctype.h>
#include <libgen.h>

#include "swiftstat_api.c"

typedef enum {USAGE, HELP, VERSION, GENERATE, FITTING, CITATION} swift_mode;


struct winsize w;

#ifdef DISABLE_THREADS
	static char usage_t_placeholder_short[] = "", usage_t_placeholder_long[] = "";
#else
	static char usage_t_placeholder_short[] = " [-t nthreads]", usage_t_placeholder_long[] = " [--threads nthreads]";
#endif

size_t ebstrlen(const char *str, size_t ub) {
	size_t i, ret;
	unsigned short skip = 0;
	for(i=0,ret=0;str[i]!=0&&(ub<0||i<ub);i++) {
		if(str[i]=='\e'&&str[i+1]=='[')
			skip = 1;
		if(skip && str[i] == 'm') {
			skip = 0;
			continue;
		}
		if(skip)
			continue;
		switch(str[i]) {
			case '\t': ret+=8; break;
			case '\n': break;
			case '\r': break;
			default: ret++; break;
		}
	}
	return ret;
}

size_t estrlen(const char *str) {
	return ebstrlen(str, -1);
}

void fwrap(FILE* out, unsigned int w, unsigned int lm, char *prefix, char *ofmt, ...) {
	char empty[1] = {0}, line[w+1], *content;
	unsigned int bufsize, buflen, bufcur = 0, linelen, i, l = 0;
	for(bufsize=512;;bufsize+=512) {
		content = calloc(sizeof(char), bufsize);
		va_list argptr;
		va_start(argptr, ofmt);
		buflen = vsnprintf(content, bufsize, ofmt, argptr);
		va_end(argptr);
		if(buflen < bufsize) break;
	}
	if(w<lm+5) {
		if(prefix == NULL) {
			fprintf(out, "%s\n", content);
		}else{
			fprintf(out, "%s %s\n", prefix, content);
		}
		return;
	}
	if(prefix!=NULL && estrlen(prefix) > lm) {
		lm = estrlen(prefix);
	}
	while(bufcur<buflen) {
		if(isspace(content[bufcur])&&l>0) {
			bufcur++;
			continue;
		}
		for(i=0;ebstrlen(&content[bufcur],i)<w-lm;i++) {
			if(content[bufcur+i]=='\n'||content[bufcur+i]==0) {
				linelen = i;
				break;
			}
			if(content[bufcur+i]==' ') {
				linelen = i;
			}
		}
		if(linelen == 0) linelen = strlen(&content[bufcur]);
		memcpy(line, &content[bufcur], linelen);
		line[linelen] = 0;
		if(l == 0 && prefix != NULL) {
			fprintf(out, "%s%*.*s%s\n", prefix, estrlen(prefix)>lm ? 0 : lm-estrlen(prefix), estrlen(prefix)>lm ? 0 : lm-estrlen(prefix), " ", line);
		}else{
			fprintf(out, "%*s%.*s\n", lm, empty, w-lm, line);
		}
		bufcur+=linelen;
		l++;
	}
	free(content);
}

void fcenterp(FILE *out, unsigned int w, char p, unsigned int im, unsigned int om, char *fmt, ...) {
	unsigned int i;
	char str[w+1];
	va_list argptr;
	va_start(argptr, fmt);
	vsnprintf(str, w, fmt, argptr);
	va_end(argptr);
	fprintf(out, "%*.*s", om, om, "");
	for(i=(w-estrlen(str)-2*(om+im))/2;i>0;i--) fwrite(&p, 1, 1, out);
	fprintf(out, "%*.*s", im, im, "");
	fwrite(str, strlen(str), 1, out);
	fprintf(out, "%*.*s", im, im, "");
	for(i=(w-estrlen(str)-2*(om+im))/2;i>0;i--) fwrite(&p, 1, 1, out);
	fprintf(out, "\n");
}

void stop(int code, char *fmt, ...) {
	char msg[512];
	va_list argptr;
	va_start(argptr, fmt);
	vsnprintf(msg, 512, fmt, argptr);
	va_end(argptr);
	if(code != 1)
		fprintf(stderr, "\e[0m\e[1m\e[31mError %d:\e[0m %s\n", code, msg);
	else
		fprintf(stderr, "\e[0m\e[1m\e[31mError:\e[0m %s\n", msg);
	exit(code);
}

void warn(char *fmt, ...) {
	char msg[500];
	va_list argptr;
	va_start(argptr, fmt);
	vsprintf(msg, fmt, argptr);
	va_end(argptr);
	fprintf(stderr, "\e[0m\e[1m\e[31mWarning:\e[0m %s\n", msg);
}

void print_usage(FILE* where, char* cmd_name) {
	fwrap(where, w.ws_col, 0, cmd_name, " -uhvfgC [-q] [-c cid [-p pid] [-P a=1.0,... [-P ...]] [-I snr] [-s sid] [-x] [-r seed] [-i input] [-e envdir] [-o output]%s]", usage_t_placeholder_short);
	fwrap(where, w.ws_col, 0, cmd_name, " --[usage|help|version|fitting|generate|citation format] [--quiet] [--corpus cid [--parix pid] [--param a=1.0,... [--param b=2.0,...]] [--sentence snr] [--seqid sid] [--fixseq] [--ranseed seed] [--input inpath] [--environ envdir] [--output outpath]%s]", usage_t_placeholder_long);
}

struct help_item {
	int key;
	char *msg;
};



int main(int argc, char **argv) {

	int i, j, k, c;

	static const size_t MAX_RANSEED = ((unsigned long) USHRT_MAX)*((unsigned long) USHRT_MAX)*((unsigned long) USHRT_MAX);

	char version_string[100];
	// get default number of threads depending on thread model specified during compiling

	#ifdef ENABLE_OPENMP
	omp_set_dynamic(0);
	const int default_num_threads = omp_get_max_threads();
	sprintf(version_string, "SWIFT v%d.%d (API v%d.%d, OpenMP threads)", swift_version.major, swift_version.minor, swift_api_version.major, swift_api_version.minor);
	#else
	#ifdef ENABLE_POSIX
	const int default_num_threads = sysconf(_SC_NPROCESSORS_ONLN);
	sprintf(version_string, "SWIFT v%d.%d (API v%d.%d, POSIX threads)", swift_version.major, swift_version.minor, swift_api_version.major, swift_api_version.minor);
	#else
	const int default_num_threads = 1;
	sprintf(version_string, "SWIFT v%d.%d (API v%d.%d, no threading)", swift_version.major, swift_version.minor, swift_api_version.major, swift_api_version.minor);
	#endif
	#endif

	// these are long argument option alternatives
	static struct option long_options[] = {
		/* These options don’t set a flag.
		 We distinguish them by their indices. */
		{"usage",   no_argument, 0, 'u'},
		{"help",   no_argument, 0, 'h'},
		{"version",   no_argument, 0, 'v'},
		{"citation",   required_argument, 0, 'C'},
		{"fitting",   no_argument, 0, 'f'},
		{"generate",   no_argument, 0, 'g'},
		{"corpus",  required_argument, 0, 'c'},
		{"seqid",   required_argument, 0, 's'},
		{"parfile",   required_argument, 0, 'p'},
		{"parix",   required_argument, 0, 'p'},
		{"param",   required_argument, 0, 'P'},
		{"ranseed",   required_argument, 0, 'r'},
		{"rand",   required_argument, 0, 'r'},
		{"output",   required_argument, 0, 'o'},
		{"input",   required_argument, 0, 'i'},
		{"environ",   required_argument, 0, 'e'},
		{"quiet",   no_argument, 0, 'q'},
		{"fixseq",   no_argument, 0, 'x'},
		{"sentence",   required_argument, 0, 'I'},
		{"item",   required_argument, 0, 'I'},
		{"threads",   required_argument, 0, 't'},
		{0}
	};

	// -t/--threads helpmsg depends on threading model
	#ifndef DISABLE_THREADS
	static char threads_helpmsg[250];
	#ifdef ENABLE_OPENMP
	sprintf(threads_helpmsg, "How many subsets to evaluate in parallel (current default: %d). Only implemented for fitting mode. Note: As this as an OpenMP version, the default can be modified by setting the environment variable OMP_NUM_THREADS.", default_num_threads);
	#else
	sprintf(threads_helpmsg, "How many subsets to evaluate in parallel (current default: %d). Only implemented for fitting mode.", default_num_threads);
	#endif
	#endif

	static char citation_helpmsg[500];
	char tmp[200] = {0};
	for(i=0;swift_citations[i].style!=NULL;i++) {
		sprintf(&tmp[strlen(tmp)], ", %s", swift_citations[i].style);
	}
	sprintf(citation_helpmsg, "Show citation for this version. Citation style to be passed as an additional argument (supported: all%s). If passed with an asterisk (*) after the citation style (e.g., all*), output is in Markdown format.", tmp);

	// these are help messages for CLI arguments
	static struct help_item help_items[] = {
		{'h', "Show help message. Other options ignored."},
		{'u', "Show command-line usage (short help). Other options ignored."},
		{'v', "Show current version. Other options ignored."},
		{'C', citation_helpmsg},
		{'f', "Enter fitting mode."},
		{'g', "Enter generative mode."},
		{'e', "Read environment (swiftstat.inp), corpus (corpus_*.dat) and expdat (ExpDat_*.dat) files from this directory (default: same as -i)."},
		{'r', "Set a random seed (long integer) for all generated random numbers."},
		{'p', "Read parameters from swpar_{cid}_{sid}_{pid}.par. If not set, read parameter from swpar_{cid}_{sid}.par."},
		{'P', "After loading parameters, update with these values. To update multiple parameters, either use this option several times (-P a=1.0 -P b=2.0), pass a comma- or semicolon-separated list (-P a=1.0,b=2.0) or both (-Pa=1.0 --param b=2.0;c=3.0)."},
		{'c', "Read corpus from corpus_{cid}.dat. Required for \e[1mgenerative\e[0m and \e[1mfitting\e[0m mode."},
		{'s', "Read fixation sequences from fixseqin_{sid}.dat."},
		{'o', "For \e[1mfitting mode\e[0m: Write log-likelihoods into this file (provide complete path). If not provided, output is written into console only. For \e[1mgenerative mode\e[0m: Write seq_{cid}_{sid}.dat and mis7_{cid}_{sid}.dat into this directory (default: ../SIM)."},
		{'i', "Find fixation sequences (fixseqin_*.dat) and parameter (swpar_*.par) files in this directory (default: ../DATA)."},
		{'I', "For \e[1mgenerative mode\e[0m, only simulate the sentence specified by the sentence number, which is to be passed as an additional argument."},
		{'x', "For \e[1mgenerative mode\e[0m, create a fixseq_*.dat file in addition to generated output (seq_*.dat)."},
		#ifndef DISABLE_THREADS
		{'t', threads_helpmsg},
		#endif
		{0}
	};

	w.ws_col = 80; // default terminal width
    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w); // try to get real terminal width in columns

    // set default values
	unsigned short verbose = 1, seq2fixseq = 0, snr=0;
	swift_mode mode = USAGE;

	// get default random seed
	unsigned long super_seed = 0l;
	FILE *ranfile = fopen("/dev/random", "r");
	if(ranfile == NULL) {
		// could not open /dev/random --> fallback to epoch time + process id + parent process id
		struct timeval t;
		gettimeofday(&t, NULL);
		super_seed = ((long)t.tv_sec*1000l) + ((long)t.tv_usec) + getpid() * getppid();
	}else{
		fread(&super_seed, 6, 1, ranfile);
		fclose(ranfile);
	}

	// set default number of threads as default number for requested number of threads
	int num_threads = default_num_threads;

	// default values for these arguments will be set after argument parsing -> NULL marks no value has been set
	char *corpus_id = NULL, *fixseq_id = NULL, *par_id = NULL, *environ_path = NULL, *inpath = NULL, *outpath = NULL, *citation_style=NULL;

	// initialize an array and mask for updated parameters
	unsigned int num_pars = sizeof(swift_parameter_names)/sizeof(char*)-1, num_ipars = sizeof(swift_discrete_parameter_names)/sizeof(char*)-1;
	double updated_values[num_pars];
	int updated_ivalues[num_ipars];
	short updated_values_mask[num_pars], updated_ivalues_mask[num_ipars];


	for(i=0;i<num_pars;i++) updated_values_mask[i] = 0;
	for(i=0;i<num_ipars;i++) updated_ivalues_mask[i] = 0;


	

	while(1) {
		int option_index = 0;
		c = getopt_long(argc, argv, "ufghvC:c:s:p:t:o:i:r:P:qxe:I:", long_options, &option_index);
		if(c == -1) {
			break;
		}

		char dummy;

		switch(c) {
			// modes
			case 'u':
				mode = USAGE;
				break;
			case 'h':
				mode = HELP;
				break;
			case 'f':
				mode = FITTING;
				break;
			case 'g':
				mode = GENERATE;
				break;
			case 'v':
				mode = VERSION;
				break;
			case 'C':
				mode = CITATION;
				if(strcmp(optarg,"all")) // if argument is "all", leave NULL
					citation_style = optarg;
				break;
			// options
			case 'c':
				corpus_id = optarg;
				break;
			case 's':
				fixseq_id = optarg;
				break;
			case 'p':
				par_id = optarg;
			case 'q':
				verbose = 0;
				break;
			case 'x':
				seq2fixseq = 1;
				break;
			case 'I':
				if(sscanf(optarg, "%hu%c", &snr, &dummy) != 1 || snr < 1) {
					stop(1, "Sentence/item number (%s) is not an integer greater than 0!", optarg);
				}
				break;
			case 'P':
				{
					int i = -1, j;
					char parname[50], tmp[50];
					double ddum;
					int idum;
					char *token = optarg;
					do {
						memset(tmp, 0, strlen(tmp)+1);
						j = 0;
						for(i++;token[i]!=0&&token[i]!='=';i++) {
							if(token[i]!=' '&&token[i]!='\t') {
								tmp[j++] = token[i];
							}				
						}
						tmp[j++] = 0;
						if(token[i]!='=') {
							stop(1, "Unrecognized parameter token '%s'! Please use parone=1.0,partwo=2.0,...", token);
						}
						sprintf(parname, "%s", tmp);
						// is this a valid model parameter?
						int par_id, par_type = 0;
						// check if this is a valid model parameter:
						par_id = get_parameter_id(parname);
						if(par_id != -1) {
							par_type = 1;
						}
						// check if this is a valid simulation parameter:
						if(par_type == 0) {
							par_id = get_discrete_parameter_id(parname);
							if(par_id != -1) {
								par_type = 2;
							}
						}
						memset(tmp, 0, strlen(tmp)+1);
						j = 0;
						for(i++;token[i]!=0&&token[i]!=','&&token[i]!=';';i++) {
							if(token[i]!=' '&&token[i]!='\t') {
								tmp[j++] = token[i];
							}
						}
						tmp[j++] = 0;
						if(token[i]!=','&&token[i]!=';'&&token[i]!=0) {
							stop(1, "Unrecognized character '%c'! Please use parone=1.0,partwo=2.0,...", token[i]);
						}
						if(par_type == 1) {
							if(sscanf(tmp,"%lf%c", &ddum, &dummy)!=1) {
								stop(1, "Unrecognized parameter token '%s'! Please use %s=123.45,...", token, parname);
							}
							updated_values_mask[par_id-1] = 1;
							updated_values[par_id-1] = ddum;
						}else if(par_type == 2) {
							if(sscanf(tmp,"%ld%c", &idum, &dummy)!=1) {
								stop(1, "Unrecognized parameter token '%s'! Please use %s=123,...", token, parname);
							}
							updated_ivalues_mask[par_id-1] = 1;
							updated_ivalues[par_id-1] = idum;
						}else {
							stop(1, "Unrecognized parameter name '%s'!\n", parname);
						}
					} while(token[i]!=0);
				}
				break;
			case 'r':
				if(sscanf(optarg, "%ld%c", &super_seed, &dummy) != 1 || super_seed < 0 || super_seed > MAX_RANSEED) {
					stop(1, "Seed provided (%s) must be an unsigned 48-bit integer (0-%ld)!", optarg, MAX_RANSEED);
				}
				break;
			case 'o':
				outpath = optarg;
				break;
			case 'i':
				inpath = optarg;
				break;
			case 'e':
				environ_path = optarg;
				break;
			case 't':
				if(sscanf(optarg, "%d%1s", &num_threads, &dummy) != 1 || num_threads < 1) {
					stop(1, "Number of threads provided (%s) is not an integer greater than 0!", optarg);
				}
				#ifndef ENABLE_OPENMP
				#ifndef ENABLE_POSIX
				warn("You requested multiple threads (using command option -t or --threads), which is not enabled and will thus be ignored. If you need to use multithreading capabilities, compile with OpenMP or POSIX threads.");
				#endif
				#endif
				break;
			default:
				warn("Unknown argument! Ignored.");
				break;
		}
	}

	if(mode == USAGE) {
		if(corpus_id != NULL || fixseq_id != NULL) {
			warn("You specified a corpus identifier (using -c or --corpus) and/or a fixation sequence identifier (using -s or --seqid). In addition, please select either fitting (using -f or --fitting) or generative (using -g or --generate) mode or see help (using -h or --help) to explore available options!");
			print_usage(stderr, basename(argv[0]));
			return 1;
		}else {
			print_usage(stderr, basename(argv[0]));
			return 0;
		}
	}else if(mode == HELP) {

		char cmd_prefix[strlen(argv[0])+5];
		sprintf(cmd_prefix, "   %s", basename(argv[0]));

		fcenterp(stderr, w.ws_col, '=', 2, 2, "\e[1m%s\e[0m", version_string);

		fprintf(stderr, "\n\e[1m\e[4mUsage:\e[0m\n");
		print_usage(stderr, cmd_prefix);

		unsigned int arglen = 0;
		for(i=0;long_options[i].name!=0;i++)
			if(strlen(long_options[i].name)>arglen)
				arglen=strlen(long_options[i].name);

		fprintf(stderr, "\n\e[1m\e[4mCommand line arguments:\e[0m\n");
		for(i=0;help_items[i].key!=0;i++) {
			char prefix[30];
			for(j=0;long_options[j].name!=0;j++)
				if(long_options[j].val==help_items[i].key)
					break;
			if(long_options[j].name!=0) {
				sprintf(prefix, "   \e[1m-%c --%s\e[0m", help_items[i].key, long_options[j].name);
				fwrap(stderr, w.ws_col, arglen+10, prefix, help_items[i].msg);
				for(k=j+1;long_options[k].name!=0;k++)
					if(long_options[k].val==help_items[i].key) {
						sprintf(prefix, "      \e[1m--%s\e[0m", long_options[k].name);
						fwrap(stderr, w.ws_col, arglen+10, prefix, "(alias for \e[1m--%s\e[0m)", long_options[j].name);
					}
			}
			else {
				sprintf(prefix, "   \e[1m-%c\e[0m", help_items[i].key);
				fwrap(stderr, w.ws_col, 18, prefix, help_items[i].msg);
			}
		}

		fprintf(stderr, "\n\e[1m\e[4mExamples:\e[0m\n");

		fprintf(stderr, "\nTo show this help message:\n");
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " --help");
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " -h");
		fprintf(stderr, "\nTo evaluate the log-likelihood of a dataset given a set of parameters:\n");
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " --fitting --corpus cid --seqid sid [--parix pid] [--param a=1.0,b=2.0,...] [--ranseed seed] [--input inpath] [--environ envdir] [--output outfile]%s", usage_t_placeholder_long);
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " -f -c cid -s sid [-p pid] [-P a=1.0,b=2.0,...] [-r seed] [-i inpath] [-e envdir] [-o outfile]%s", usage_t_placeholder_short);
		fprintf(stderr, "\nTo simulate a dataset given a corpus (cid) and a set of parameters:\n");
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " --generate --corpus cid --seqid sid [--parix pid] [--sentence snr] [--param a=1.0,b=2.0,...] [--ranseed seed] [--fixseq] [--input inpath] [--environ envdir] [--output outpath]");
		fwrap(stderr, w.ws_col, 0, cmd_prefix, " -g -c cid -s sid [-p pid] [-I snr] [-P a=1.0,b=2.0,...] [-r seed] [-x] [-i inpath] [-e envdir] [-o directory]");
		return 0;
	}else if(mode == VERSION) {
		printf("%s\n", version_string);
		return 0;
	}else if(mode == CITATION) {
		unsigned int markdown = 0;
		if(citation_style != NULL && citation_style[strlen(citation_style)-1] == '*') {
			markdown = 1;
			citation_style[strlen(citation_style)-1] = 0;
		}
		if(citation_style == NULL || !strcmp(citation_style, "all")) {
			for(i=0;swift_citations[i].style!=NULL;i++) {
				char *ret = NULL;
				if(markdown) {
					ret = swift_citations[i].markdown;
				} else {
					ret = swift_citations[i].plain;
				}
				if(ret!= NULL)
					fprintf(stdout, "\e[2m%s\e[22m: %s\n", swift_citations[i].style, ret);
			}
			return 0;
		} else {
			swift_citation *swift_cite = swift_find_citation_style(citation_style);
			if(swift_cite != NULL) {
				char *ret = NULL;
				if(markdown) {
					ret = swift_cite->markdown;
				} else {
					ret = swift_cite->plain;
				}
				if(ret == NULL) {
					stop(1, "The citation style '%s' is not available in the requested format!", citation_style);
				}else{
					fprintf(stdout, "%s\n", ret);
					return 0;
				}
			}
			stop(1, "Unknown citation format '%s'! Please see help (%s -h) for supported citation formats!", citation_style, basename(argv[0]));
		}
	}else if(mode == FITTING || mode == GENERATE) {
		char corpus_file[PATH_MAX], fixseq_file[PATH_MAX], par_file[PATH_MAX];
		if(inpath  == NULL) 
			inpath = "../DATA";

		if(environ_path == NULL) 
			environ_path = inpath;

		if(corpus_id == NULL)
			stop(1, "Corpus identifier must be specified (using -c or --corpus, see --help)!");
		
		sprintf(corpus_file, "%s/corpus_%s.dat", environ_path, corpus_id);
		if(fixseq_id == NULL)
			stop(1, "Fixation sequence identifier must be specified (using -s or --seqid, see --help)!");
		
		sprintf(fixseq_file, "%s/fixseqin_%s.dat", inpath, fixseq_id);
		if(par_id == NULL) {
			sprintf(par_file, "%s/swpar_%s_%s.par", inpath, corpus_id, fixseq_id);
		}else{
			sprintf(par_file, "%s/swpar_%s_%s_%s.par", inpath, corpus_id, fixseq_id, par_id);
		}

		if(verbose) {
			fcenterp(stdout, w.ws_col, '=', 2, 2, "\e[1m%s\e[0m", version_string);
			printf("\n\tRandom seed: %ld\n\n", super_seed);
		}

				swift_model *model;

		int errcode;

		// Load model

		errcode = swift_load_model(environ_path, par_file, corpus_file, super_seed, &model, verbose);
		
		if(errcode) stop(errcode, "Loading model failed: %s", swift_last_error->msg);

		if(verbose) printf("\n\t5. Update parameters:\n");
		// Update model parameters
		unsigned short has_updated_parameters = 0;
		for(i=0;i<num_pars;i++) {
			if(updated_values_mask[i]) {
				swift_set_parameter(i+1, updated_values[i], model);
				if(verbose) printf("\t  %10s = %lf\n", get_parameter_name(i+1), updated_values[i]);
				has_updated_parameters = 1;
			}
		}
		for(i=0;i<num_ipars;i++) {
			if(updated_ivalues_mask[i]) {
				swift_set_discrete_parameter(i+1, updated_ivalues[i], model);
				if(verbose) printf("\t  %10s = %ld\n", get_discrete_parameter_name(i+1), updated_ivalues[i]);
				has_updated_parameters = 1;
			}
		}
		if(!has_updated_parameters&&verbose) printf("\n\t   (none)\n");

		if(mode == FITTING) {
			swift_data *cdata;

			errcode = swift_load_data(fixseq_file, &cdata, verbose);

			if(errcode) stop(errcode, "Loading data failed: %s", swift_last_error->msg);

			if(verbose) {
				printf("\n\t6. Fitting empirical data:\n");
				printf(  "\t   %d fixations in %d trials\n",cdata->Nfix,cdata->Ntrials);
			}

			double retvals[N_LOGLIKS]; // if no outputfile specified, get them here

			#ifdef DISABLE_THREADS
			if(verbose) printf(  "\t   evaluating entire dataset serially...\n");
			swift_model_main_eval(model, cdata, NULL, &retvals[0], outpath);
			free_swift_data(cdata);
			#else
			swift_data_subsets *sdata;
			swift_subset_data(cdata, num_threads, &sdata, 0);
			free_swift_data(cdata);
			if(verbose) printf(  "\t   evaluating %d subsets in parallel...\n", sdata->Nsubsets);
			swift_model_main_eval_subsets(model, sdata, &retvals[0], outpath);
			free_swift_data_subsets(sdata);
			#endif

			for(i=0;i<N_LOGLIKS;i++) {
				if(i>0&&verbose) printf(", ");
				else if(i>0) printf(" ");
				else if(verbose) printf("\n\tloglik: ");
				printf("%lf", retvals[i]);
				if(i==N_LOGLIKS-1) printf("\n");
			}
			

			free_swift_model(model);

		}else if(mode == GENERATE) {

			if(outpath == NULL)
				outpath = "../SIM";

			if(snr > model->nos) {
				stop(2, "The sentence/item requested (%hu) was not found in corpus %s! Valid values for this corpus are 1..%d.", snr, corpus_id, model->nos);
			}

			char output_name[strlen(corpus_id)+strlen(fixseq_id)+2];
			sprintf(output_name, "%s_%s", corpus_id, fixseq_id);

			if(snr == 0)
				swift_model_main_generate(model, outpath, output_name, verbose);
			else
				swift_model_main_generate_single(model, outpath, output_name, snr, verbose);

			if(seq2fixseq) {
				if(snr>0) {
					warn("Translation from single-item simulation to fixseqin*.dat file is not supported.");
				}else{
					char seq_file[PATH_MAX], fixseq_file[PATH_MAX];
					sprintf(seq_file, "%s/seq_%s.dat", outpath, output_name);
					sprintf(fixseq_file, "%s/fixseqin_%s.dat", outpath, fixseq_id);
					swift_seq2fixseqin(seq_file, fixseq_file);
				}
			}

			free_swift_model(model);

		}

		if(swift_last_error != NULL) {
			stop(swift_last_error->code, "Uncaught error: %s", swift_last_error->msg);
		}

		return 0;
		
	}


	warn("There was nothing to do.");

	return 1;
	
}

/*------------------------------------------
 Simulation of the SWIFT model along experimental data
 --------------------------------------------*/

#define sq(A) ((A)*(A))

double model_main(int nos, int *slen, double *wfreq, int *wlen, double *wpred, int nread,
                double *s1, double *s2, double *r1, double *r2, double **par, int npar,
                long *seed, int output,
                char *fpath, int **fixseqs,double *flet, int fitting, int Nfix, double *weighted_loglik, int verbose)
{
    FILE      *fsim, *f_fit;
    char      seqtmp[300];
    double    **inhvec;
    double    *pred, *lex, *view, *border, *kvec, *kv, *freq, *tvec;
    double    *labv1, *labv2, *nlabv1, *nlabv2;
    double    *r_count, *W, *p_trans, *t_hist, dt_nlab;
    double    *procrate, *Ptar;
    double    alpha, beta, msac, deltar, deltal, eta, h, ppf;
    double    delta0, delta1, asym, logf, iota, labrate;
    double    decay, msac0, tau_l, tau_n, tau_ex, gamma;
    double    t, t_fix;
    double    randpar, theta, dynfac, misfac, inhibrate;
    double    inhib, kpos, saclen, saccerr;
    double    presaclen, Pcomb;
    double    kappa0, kappa1, kapparate, dt, aord, cord, lord, nord, xord, refix;
    double    x, Wsum, rnd, psum, proc, maxfreq, dist, sacamp, misprob;
    double    ifovea, minact, ptheo;
    double    mlp, prev_mlp, upcoming_l_pos;
    double    loglik_temp, loglik_spat;
    int       *acompletion, **mat;
    double    *aa,  *aa_labtrans,**a_hist;
    int       *n1, *nf1, *n2, *nf2;
    int       *len, *as, *adir;
    int       *n_count, *N_count;
    int       refix_sw_cur, refix_sw_prev;
    int       NW, lab, nlab, sacc, num, misloc, Nrefix;
    int       k_fix, n_fix, next_tar, intended;
    int       endsw_sentence, endsw_trial, canc;
    int       presac, testreg, firstpass;
    int       i, j, k, l, last, run, s, s0, w, w0, n_hist, trans_point;
    int       state, SACORDl, SACORDn, SACORDx, TIMORD;
    int       cur_fix, n_trans, nsims;
    
    num = misloc = Nrefix= 0;
    weighted_loglik[0] = 0;
    weighted_loglik[1] = 0;
    
    // fixed parameters
    nsims = 300;

    // free parameters
    for ( i=1; i<=npar; i++ ) {
        randpar = par[i][1];
        switch (i) {                    // NOTE: parameter-number pairing MUST be the same as in swiftstat6.c !!!
            case  1:   delta0  = randpar;  break; // nondynamical processing span in letter spaces
            case  2:   delta1  = randpar;  break; // dynamical processing span in letter spaces
            case  3:   beta    = randpar;  break; // frequency modulation
            case  4:   msac    = randpar;  break; // relative duration of global saccade program
            case  5:   h       = randpar;  break; // foveal inhibition-factor
            case  6:   ppf     = randpar;  break; // inhibition from words to the left of fixation
            case  7:   iota    = randpar;  break; // transfer across saccades (activation loss during saccade)
            case  8:   msac0   = randpar;  break; // relative duration of first fixation in the sentence
            case  9:   refix   = randpar;  break; // relative duration of the labile saccade stage for refixations
            case 10:   misfac  = randpar;  break; // relative duration of the labile saccade stage for misplaced fixations
            case 11:   kappa0  = randpar;  break; // nonlabile latency dependence on target distance (Kalesnykas & Hallet)
            case 12:   kappa1  = randpar;  break; //
            case 13:   proc    = randpar;  break; // relative processing speed for postlexical processing (as[]=2)
            case 14:   decay   = randpar;  break; // global decay during postlexical processing
            case 15:   theta   = randpar;  break; // influence of predicatibility processing speed
            case 16:   gamma   = randpar;  break; // target selection exponent
            case 17:   tau_l   = randpar;  break; // mean duration of the labile saccade program
            case 18:   tau_n   = randpar;  break; // mean duration of the nonlabile saccade program
            case 19:   tau_ex  = randpar;  break; // mean saccade duration
            case 20:   alpha   = randpar;  break; //
            case 21:   asym    = randpar;  break; // asymmetry of processing span to the right
            case 22:   eta     = randpar;  break; // word length exponent
            case 23:   aord    = randpar;  break; // order of random walks for word activation (maximum)
            case 24:   cord    = randpar;  break; // order of random walks for global saccade program & labile stage
            case 25:   lord    = randpar;  break; // order of random walks for nonlabile stage, saccade execution & perceptual delay
            case 26:   nord    = randpar;  break;
            case 27:   xord    = randpar;  break;
            case 28:   minact  = randpar;  break; // minimum activation threshold of words for target selection
            case 29:   misprob = randpar;  break; // mislocated fixation probability multiplier
                // 16 oculomotoric parameters
        }
    }
    
    /* rescale parameters */
    msac = msac*100.0;
    tau_l = tau_l*100.0;
    tau_n = tau_n*100.0;
    tau_ex = tau_ex*100.0;

    /* open output files */
    if ( output==0 && fitting == 0 )  {
        sprintf(seqtmp, "%s_seq.dat", fpath);
        fsim = fopen(seqtmp, "w");
    }
    if ( output>0 ) {
        s0 = output; // only read sentence of number "output", no more and only once (for diagnostics)
        nos = s0;
        nread = 1;
        sprintf(seqtmp, "%s_seq.dat", fpath);
        fsim = fopen(seqtmp, "w");
    }  else  s0=1;
    
    if ( fitting != 0 ) {
        // read every sentence just once to get an estimate of refixation and mislocated fixation rates
        if ( fitting == -1 ) { 
            nread = 1;
            nerror("old code: should not happen");
        } else {
            if ( fpath != NULL )  {
                sprintf(seqtmp, "%s", fpath); // open output-file
                f_fit = fopen(seqtmp,"a");
            }
        }
    }
    
    /* Determine maximum of word frequency */
    w0 = 0;
    maxfreq = wfreq[1];
    for ( s=1; s<=nos; s++ )  {
        for ( w=1; w<=slen[s]; w++ )  {
            wfreq[w0+w] = wfreq[w0+w] + 1.0; // so that freqs cannot be < 1
            if ( wfreq[w0+w]>maxfreq )  maxfreq = wfreq[w0+w];
        }
        w0 += slen[s];
    }
    maxfreq = log(maxfreq);
    
    /* loop over sentences */
    cur_fix = 1;
    for ( s=s0; s<=nos; s++ ) {
        NW = slen[s];
        for ( i=1, w0=0; i<s; i++ )  w0 += slen[i];
        
        // independent variables (predictors)
        freq = dvector(1,NW);
        len = ivector(1,NW);
        pred = dvector(1,NW);
        for ( w=1; w<=NW; w++ )  {
            freq[w] = wfreq[w0+w];
            pred[w] = wpred[w0+w];
            len[w] = wlen[w0+w];
        }
        
        /* declaration of vectors */
        as = ivector(1,NW);              /* pre-proc./lex. completion? (0/1) */
        adir = ivector(1,NW);            /* rw direction */
        lex = dvector(1,NW);             /* lexical difficulty */
        view = dvector(1,NW);            /* optimal viewing positions */
        border = dvector(1,NW);          /* word borders */
        kvec = dvector(1,100*NW);        /* fixation position */
        tvec = dvector(1,100*NW);        /* time */
        mat = imatrix(1,100*NW,1,3);     /* fixations */
        inhvec = dmatrix(1,10000*NW,1,4);  /* inhibition vector */
        labv1 = dvector(1,cord);
        labv2 = dvector(1,cord);
        nlabv1 = dvector(1,cord);
        nlabv2 = dvector(1,cord);
        procrate = dvector(1,NW);        /* processing rate (time-dependent)*/
        a_hist = dmatrix(1,(int) (aord*3*NW+0.1),1,NW);  /* activation field history (with t_hist & n_hist) */
        t_hist = dvector(1,(int) (aord*3*NW+0.1));
        aa_labtrans = dvector(1,NW);     /* activations at transition between lab/nonlab phase */
        Ptar = dvector(1,NW);            /* probabilities of target words being selected */
        
        /* loop over realizations */
        if ( fitting <= 0 ) {
            run = 1; // number of times sentence s has been read
            endsw_sentence = run > nread;
        } else {
            endsw_sentence = ( cur_fix > Nfix || fixseqs[cur_fix][1] != s );
        }
        
        
        // loop over trials
        while (endsw_sentence == 0) {
            // variable controlling random walks
            // NW+4 random walks for NW words plus timer, 3 saccade stages
            TIMORD = (int) cord;
            SACORDl = (int) lord;
            SACORDn = (int) nord;
            SACORDx = (int) xord;
            N_count = ivector(1,4+NW);
            N_count[1] = TIMORD;
            N_count[2] = SACORDl;
            N_count[3] = SACORDn;
            N_count[4] = SACORDx;

            r_count = dvector(1,4+NW);
            r_count[1] = (1.0*N_count[1])/(1.0*msac);
            r_count[2] = (1.0*N_count[2])/(1.0*tau_l);
            r_count[3] = (1.0*N_count[3])/(1.0*tau_n);
            r_count[4] = (1.0*N_count[4])/(1.0*tau_ex);
            
            n_count = ivector(1,4+NW);
            for ( l=1; l<=4+NW; l++ )  n_count[l] = 0;
            W = dvector(1,4+NW);
            p_trans = dvector(1,4+NW);
            
            /* initialization of dynamical variables */
            aa = dvector(1,NW);
            acompletion = ivector(1,NW);

            for ( i=1; i<=NW; i++ )  {
                aa[i] = 0.0;      // word-based activations
                as[i] = 1;      // processing state
                adir[i] = 1;    // random-walk direction
                acompletion[i] = 1;   // =0 if word is completely processed
                logf = log(freq[i])/maxfreq;
                if ( logf<0.0 )  logf = 0.0;
                lex[i] = 1.0 - beta*logf;   // word frequency effect
                lex[i] = alpha*lex[i];
                N_count[4+i] = (int) (aord+0.1);  // proportion of maximum activation aord
                
                /* compute optimal viewing positions and word borders */
                if ( i==1 )  {
                    view[i] = len[i]/2.0 + 1.0; 
                    border[i] = len[i] + 1.0;
                }
                else  {
                    view[i] = border[i-1] + (len[i]/2.0) + 1.0;
                    border[i] = border[i-1] + len[i] + 1.0;
                }
            }           


            if ( fitting <= 0 ) {
                k = 1;                       /* fixated word */
                kpos = view[1];              /* first fixation position given by OVP */
            } else {
                k = fixseqs[cur_fix][2];     /* fixated word */
                if ( k==1 ) {                /* first fixation position given by data */
                    kpos = flet[cur_fix];
                } else {
                    kpos = border[k] - (len[k] + 1) + flet[k];
                }
            }
            last        = 0;                 /* last fixated word */
            t           = 0.0;               /* time */
            lab         = 0;                 /* labile saccade program? (0/1) */
            labrate     = 0.0;
            nlab        = 0;                 /* non-labile saccade program? (0/1) */
            sacc        = 0;                 /* saccade in execution? (0/1) */
            next_tar    = 1;                 /* target of next saccade */
            intended    = 1;                 /* intended target word */
            dist        = 0.0;               /* distance of next saccade target */
            mlp         = 0.0;
            
            /*-------------------------
             simulation algorithm
             -------------------------*/
            t_fix = 0.0;
            k_fix = 1;
            n_fix = 0;
            n_count[1] = (int) (msac0*N_count[1]);
            canc = 0;
            
            if ( fitting <= 0 ) {
                endsw_trial = 0;
            } else {
                endsw_trial = fixseqs[cur_fix][6] == 2;
                n_hist = 0;                          /* count changes of activation */
                n_trans = 0;                         /* transition counter for inhibition vector */
                upcoming_l_pos = 0.0;                /* support variable for fitting */
                loglik_temp = 0.0;                   /* support variable for fitting */
                loglik_spat = 0.0;                   /* support variable for fitting */
            }
            
            // sim: read sentence either until completion, running out of time or to a maximum of 3*NW fixations
            // fit: read sentence until end of trial (don't evaluate last fixation)
            while ( endsw_trial == 0 ) {
                
                /* compute inhibition */
                ifovea = aa[k]/aord;  
                inhib = h*ifovea;
                if ( inhib<0.0 )  inhib = 0.0;
                
                /* iterate lexical processing with time step dt */
                lexrate(aa,as,view,len,aord,alpha,delta0,delta1,asym,pred,proc,ppf,theta,decay,eta,NW,kpos,k,0,procrate,fitting);
                
                /* Gillespie algorithm */
                /* total transition probability */
                inhibrate = 1.0/(1.0+inhib);
                W[1] = r_count[1]*inhibrate;                            /* rate of random walk for timer */
                W[2] = r_count[2]*lab*labrate;                          /* rate of random walk for labile sacprog stage */
                kapparate = 1.0/(1.0 + kappa0*exp(-kappa1*sq(dist)));
                W[3] = r_count[3]*nlab*kapparate;                        /* ... nonlabile stage */
                W[4] = r_count[4]*sacc;                                  /* ... saccade execution */
                for ( i=1; i<=NW; i++ )  W[4+i] = aord/alpha*procrate[i]*acompletion[i];
                /* acompletion = 1: not fully processed; acompletion = 0: fully processed */
               
                /* exponential pausing time */
                for ( i=1, Wsum = 0.0; i<=4+NW; i++ )  Wsum += W[i];

                dt = -1.0/Wsum*log(1.0-ran1(seed));
                
                /* fitting: update time & compare with experimental fixation duration */
                if ( fitting==1 && (t+dt-t_fix)>= (double) fixseqs[cur_fix][4] ) {  // don't increment time above fixation duration
                    fitting = 2;
                    
                    // select upcoming target from experimental data
                    next_tar = fixseqs[cur_fix+1][2];
                    
                    // instead of simulated duration of nonlabile phase use its mean duration "tau_n"
                    dt_nlab = tau_n;
                    
                    // set end-time of fixation according to data
                    t = t_fix + (double) fixseqs[cur_fix][4];
                    
                    // initialize history if no activations have been saved yet
                    if ( n_hist == 0) {
                        for (i = 1; i<=NW; i++) a_hist[1][i] = 0.0;
                        t_hist[1] = 0.0;
                    }
                    // deal with cases of very short initial fixations (sentence wise)
                    if ( n_hist == 0 || (t-t_hist[1]) < dt_nlab ) {
                        trans_point = 1;
                    } else {
                        // find index of activations at transition from labile to nonlabile stage
                        trans_point = n_hist+1;
                        while (t_hist[--trans_point] > (t - dt_nlab));
                    }
                    
                    // convert activations to vector form for compatibility with selectar
                    for ( i=1; i<=NW; i++) aa_labtrans[i] = a_hist[trans_point][i];
                    
                    // compute probabilities for all target words at time of transition
                    selectar(aa_labtrans,as,k,NW,gamma,seed,fitting,minact,Ptar);
                    
                    // upcoming letter position
                    if ( fixseqs[cur_fix+1][2]==1 ) {
                        upcoming_l_pos = flet[cur_fix+1];
                    } else {
                        upcoming_l_pos = border[fixseqs[cur_fix+1][2]] - ( len[fixseqs[cur_fix+1][2]] + 1 ) + flet[cur_fix+1];
                    }
                    sacamp = fabs(upcoming_l_pos - kpos);
                    
                    // compute probabilities for letter position, given all target words
                    for ( i=1; i<=NW; i++) {
                        Ptar[i] *= execsacc(&kpos,&k,&i,view,border,len,NW,s1,s2,r1,r2,seed,0,fitting,upcoming_l_pos);
                    }
                    
                    // multiply probabilies, calculate likelihood
                    if ( fixseqs[cur_fix][6] == 0) {  // exclude first and last fixation (==1 or 2)
                        Pcomb = 0.0;
                        for ( i=1; i<=NW; i++)  Pcomb += Ptar[i];
                        loglik_spat += log(Pcomb);
                    }
                    
                    // Is the current fixation a refixation?
                    refix_sw_cur = 0;
                    if ( ( cur_fix>1 ) && ( fixseqs[cur_fix][2]==fixseqs[cur_fix-1][2] ) ) refix_sw_cur = 1;

                    refix_sw_prev = 0;
                    if ( ( cur_fix>2 ) && (fixseqs[cur_fix-1][6]==0) && ( fixseqs[cur_fix-1][2]==fixseqs[cur_fix-2][2] ) ) refix_sw_prev = 1;                    
                    
                    prev_mlp = mlp;
                    
                    if ( k==1 )  mlp = misprob*sq(sq((kpos-0.5*len[k])/(0.5*len[k])));
                    else mlp = misprob*sq(sq((kpos-border[k-1]-0.5*len[k])/(0.5*len[k])));
                    if ( mlp>misprob )  mlp=misprob;
                    
                    // compute probability for fixation duration
                        if ( fixseqs[cur_fix][6] == 0) { // exclude first and last fixation
                            x = (t - t_fix);
                            ptheo = likPDA(x,cord,lord,nord,xord,msac,tau_l,tau_n,tau_ex,misprob,misfac,refix_sw_cur,refix_sw_prev,0,refix,sacamp,kappa0,kappa1,t,t_fix,inhvec,n_trans,nsims,2,seed,mlp,prev_mlp);
                            loglik_temp += 3+ptheo;
                        }
                    
                    // initiate saccade
                    n_count[1] = 0;
                    n_count[2] = 0;
                    n_count[3] = N_count[3];
                    n_count[4] = 0;

                    // prevent anything else from happening
                    for ( i=1; i<=4+NW; i++) W[i] = 0.0;
                    
                } else {
                    if ( fitting > 0 ) {
                        n_trans++;
                        inhvec[n_trans][1] = t;
                        inhvec[n_trans][2] = inhibrate;
                        inhvec[n_trans][3] = labrate;
                        inhvec[n_trans][4] = kapparate;
                    }
                    t += dt; // update time
                }
                
                /* determine transition by relative transition probability */
                psum = 0.0;
                for ( i=1; i<=4+NW; i++ )  {
                    p_trans[i] = W[i];
                    psum += p_trans[i];
                }
                for ( i=1; i<=4+NW; i++ )  p_trans[i] /= psum;
                
                /* linear selection algorithm */
                rnd = ran1(seed);
                psum = p_trans[1];
                state = 1;
                while ( psum < rnd )  {
                    state++;
                    psum += p_trans[state];
                }
                
                /* perform transition     */
                /* oculomotor transitions */
                if ( state<=4 )  n_count[state]++;
                else  {
                    /* transitions in lexical activations */
                    j = state-4;
                    n_count[state] += adir[j];   /* lexical activations are changing in incremental steps of +1 or -1 */
                    
                    /* from lexical to postlexical processing */
                    if ( as[j]==1 && n_count[state]>=N_count[state] )  {
                        as[j] = 2;
                        adir[j] = -1;
                        n_count[state] = N_count[state];
                    }
                    
                    /* processing completed: lexical activation back to zero */
                    if ( as[j]==2 && n_count[state]<=0 )  {
                        as[j] = 3;
                        acompletion[j] = 0;
                        n_count[state] = 0;
                    }
                    
                    if ( as[j]==1 )  adir[j] = 1;
                    
                    /* update activation */
                    aa[j] = lex[j]*((1.0*n_count[state])/(aord));
                    
                    /* save activation field history */
                    if ( fitting > 0 ) {
                        n_hist++;
                        t_hist[n_hist] = t;
                        for ( i=1; i<=NW; i++ )  a_hist[n_hist][i] = aa[i];
                    }
                }
                
                /* check ongoing nlabile saccade program)  */
                if ( n_count[2]>=N_count[2] && (nlab==1 || sacc == 1))  {
                    n_count[2] = N_count[2]; // labile stage offset cannot start two concurring nonlabile phases
                    labrate = 0.0;
                }

                /* start new labile saccade program */
                if ( n_count[1]>=N_count[1] )  {
                    if ( lab==1 )  canc++;
                    n_count[1] = 0;
                    n_count[2] = 0;
                    lab = 1;
                    labrate = 1.0;
                }
                
                /* initiate non-labile saccade program */
                if ( nlab==0 && sacc == 0 && n_count[2]>=N_count[2] ) {
                    canc = 0;
                    n_count[2] = 0;
                    nlab = 1;
                    n_count[3] = 0;
                    lab = 0;
                    
                    /* select next target word */
                    if ( fitting <= 0 ) {
                        next_tar = selectar(aa,as,k,NW,gamma,seed,fitting,minact,0);
                        /* non-labile saccade program as a function of saccade length */
                        dist = fabs( view[next_tar] - kpos );
                    }
                }
                
                /* initiate saccade / fixation offset */
                if ( n_count[3]>=N_count[3] && fitting != 1 ) {
                    nlab = 0;
                    sacc = 1;
                    n_count[4] = 0;
                    n_count[3] = 0;
                    
                    /* save fixation data in matrix mat() */
                    n_fix = n_fix + 1;
                    mat[n_fix][1] = k_fix;
                    mat[n_fix][2] = (int) (t-t_fix);
                    mat[n_fix][3] = intended;
                    kvec[n_fix] = kpos;
                    tvec[n_fix] = t_fix;
                    num++;
                    if ( intended!=k_fix )  misloc++;
                }
                
                /* end of saccade execution / fixation onset */
                if ( n_count[4]>=N_count[4] ) {
                    saclen = kpos;
                    intended = next_tar;
                    last = k;          /* last fixation */
                    if ( fitting <= 0 ) {
                        saccerr = execsacc(&kpos,&k,&next_tar,view,border,len,NW,s1,s2,r1,r2,seed,0,fitting,0);
                    } else {
                        fitting = 1;
                        cur_fix++;
                        kpos = upcoming_l_pos;
                        saccerr = kpos - view[next_tar];
                        k = fixseqs[cur_fix][2];
                    }
                    saclen = kpos - saclen;
                    t_fix = t;         /* start of fixation */
                    k_fix = k;         /* fixation position */
                    sacc = 0;          /* stop saccade */
                    n_count[4] = 0;

                    /* reset of lexical activation after saccade */
                    for ( i=1; i<=NW; i++ )  {
                        if ( as[i]==1 )  n_count[i+4] = (int) (iota*n_count[i+4]);
                    }
                    
                    if ( fitting==0 ) {

                        /* refixation? */
                        if ( last==k )  {
                            lab = 1;
                            labrate = refix;
                            n_count[2] = 0;
                            n_count[1] = 0;
                            Nrefix++;
                        }
                        
                        /* mislocated fixation: program error-correcting saccade */
                        if ( k==1 )  mlp = misprob*sq(sq((kpos-0.5*len[k])/(0.5*len[k])));
                        else mlp = misprob*sq(sq((kpos-border[k-1]-0.5*len[k])/(0.5*len[k])));
                        if ( mlp>misprob )  mlp=misprob;
                        if ( ran1(seed)<=mlp )  {
                            lab = 1;
                            labrate = misfac;
                            n_count[2] = 0;
                            n_count[1] = 0;
                        }

                        /* waiting for end of nl phase + saccade */
                        if ( n_count[2]>=N_count[2] ) {
                            n_count[2] = 0;
                            lab = 0;
                            nlab = 1;
                        }
                    }
                }
                
                /* write output (full trajectory) */
                if ( output>0 ) {
                    fprintf(fsim,"%.1f\t",t);
                    for ( i=1; i<=NW; i++ )  fprintf(fsim,"%f\t",aa[i]);
                    
                    /* dynamical processing span */
                    dynfac = 1.0 - aa[k]/alpha;
                    if ( as[k]==1 )  dynfac = 0.0;
                    deltar = delta0 + delta1*dynfac;
                    deltal = delta0*asym;
                    
                    fprintf(fsim,"%f\t%d\t%d\t%d\t%d\t%d\t%f\t%f\t%f\t%f",kpos,k,sacc,lab,nlab,next_tar,deltar,deltal,loglik_temp,loglik_spat);
                    for ( l=1; l<=4; l++ )  fprintf(fsim,"\t%d",n_count[l]);
                    fprintf(fsim,"\n");
                }
                
                /* check for end of simulation of trial */
                if ( fitting <= 0 ){
                    for ( i=1, endsw_trial=1; i<=NW; i++ )  if ( as[i]!=3 )  endsw_trial = 0;
                    endsw_trial = (endsw_trial != 0 || t >= 5000.0 || n_fix >= 3*NW);
                } else {
                    endsw_trial = fixseqs[cur_fix][6] == 2;
                }
            } /* end of while loop Gillespie algorithm */
            
            if ( fitting > 0 ) {
                // advance fixation counter to the first fixation of the upcoming trial/sentence
                cur_fix++;
                if ( n_fix > 2 ) {
                    // average computed likelihoods of preceding trial by number of fixations
                    weighted_loglik[0] += loglik_temp / (n_fix - 2.0);  // -2.0 since first and last fixations have no likelihood (also implicit double conversion)
                    weighted_loglik[1] += loglik_spat / (n_fix - 2.0);
                } else {
                    // just in case..
                    weighted_loglik[0] += loglik_temp;
                    weighted_loglik[1] += loglik_spat;
                }
            }
            
            
            if ( output>0 && verbose )  for ( i=1; i<=NW; i++ )  printf("%d\t%d\n",i,as[i]);
            
            /* write output (sequence) */
            if ( output==0 && fitting == 0 ) {
                /* number of fixation in first-pass and second-pass (cnfix) */
                nf1 = ivector(1,NW); /* total number of fixation in first-pass */
                nf2 = ivector(1,NW); /* total number of fixation in second-pass */
                testreg = 0;
                for ( i=1; i<=NW; i++ )  nf1[i] = nf2[i] = 0;
                firstpass = 0;
                for ( i=1; i<=n_fix; i++ ) {
                    k = mat[i][1];
                    if ( i>1 ) {
                        if ( k<mat[i-1][1] )  {
                            if ( mat[i-1][1]>firstpass )  firstpass = mat[i-1][1];
                            testreg = 1;
                        }
                    }
                    if ( k>firstpass ) nf1[k]++;
                    else nf2[k]++;
                }
                
                /* write output file */
                kv = dvector(1,n_fix);
                n1 = ivector(1,NW);
                n2 = ivector(1,NW);
                for ( i=1; i<=NW; i++ )  n1[i] = n2[i] = 0;
                firstpass = 0;
                for ( i=1; i<=n_fix; i++ ) {
                    k = mat[i][1];   /* fixated word */
                    /* fixation in first or second-pass (xnfix) */
                    if ( i>1 ) {
                        if ( k<mat[i-1][1] )  {
                            if ( mat[i-1][1]>firstpass )  firstpass = mat[i-1][1];
                            testreg = 1;
                        }
                    }
                    for ( j=1; j<=firstpass; j++ )  n1[j] = 0;
                    if ( k>firstpass ) n1[k]++;
                    else n2[k]++;
                    /* type of preceding saccade */
                    presac = -999;
                    if ( i>1 )  presac = k - mat[i-1][1];
                    /* length of preceding saccade */
                    presaclen = -999.99;
                    if ( i>1 )  presaclen = kvec[i] - kvec[i-1];
                    /* landing position (continuous) */
                    if ( k==1)  kv[i] = kvec[i]; 
                    if ( k>1 )  kv[i] = kvec[i] - border[k-1];
                    /* first or last fixation (1/2)? */
                    w = 0;
                    if ( i==1 )  w = 1;
                    if ( i==n_fix )  w = 2;
                    fprintf(fsim,"%d\t%d\t%d\t%.2f\t%d\t%d\t%.2f\t%d\t%.2f\t%.2f\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%f\t%.2f\t%.2f\n",
                            run,s,k,kv[i],mat[i][2],presac,presaclen,
                            len[k],freq[k],pred[k],w,n1[k],nf1[k],n2[k],nf2[k],testreg,mat[i][3],0.0,0.0,tvec[i]);
                }
                free_dvector(kv,1,n_fix);
                free_ivector(n2,1,NW);
                free_ivector(n1,1,NW);
                free_ivector(nf2,1,NW);
                free_ivector(nf1,1,NW);
            }
            
            free_ivector(acompletion,1,NW);
            free_dvector(aa,1,NW);
            free_dvector(p_trans,1,4+NW);
            free_dvector(W,1,4+NW);
            free_ivector(n_count,1,4+NW);
            free_dvector(r_count,1,4+NW);
            free_ivector(N_count,1,4+NW);
            
            // endswitch for realizations of one sentence -> next sentence please
            if ( fitting <= 0 ) {
                run++;
                endsw_sentence = run > nread;
            } else {
                endsw_sentence = ( cur_fix > Nfix || fixseqs[cur_fix][1] != s );
            }
        }
        
        free_dvector(Ptar, 1,NW);
        free_dvector(aa_labtrans, 1,NW);
        free_dvector(t_hist,1,aord*3*NW);
        free_dmatrix(a_hist,1,aord*3*NW,1,NW);
        free_dvector(procrate,1,NW);
        free_imatrix(mat,1,100*NW,1,3);
        free_dmatrix(inhvec,1,10000*NW,1,4);
        free_dvector(labv1,1,cord);
        free_dvector(labv2,1,cord);
        free_dvector(nlabv1,1,cord);
        free_dvector(nlabv2,1,cord);
        free_dvector(tvec,1,100*NW);
        free_dvector(kvec,1,100*NW);
        free_dvector(border,1,NW);
        free_dvector(view,1,NW);
        free_dvector(lex,1,NW);
        free_ivector(adir,1,NW);
        free_ivector(as,1,NW);
        free_dvector(pred,1,NW);
        free_ivector(len,1,NW);
        free_dvector(freq,1,NW);
        
    }
    
    if ( fitting == 0 ) {
        if ( output >= 0 )  fclose(fsim);
        if ( output == 0 )  {
            if(verbose) {
                printf("\n\t  Fixations:  %d\n",num);
                printf("\tRefixations:  %d\n",Nrefix);
            }
        }
        return 0;
    } else if (fitting > 0) {
        if (output>0) fclose(fsim);
        if ( fpath != NULL )  {
            fprintf(f_fit, "%f\t%f\n", weighted_loglik[0], weighted_loglik[1]);
            fclose(f_fit);
            return weighted_loglik[0]+weighted_loglik[1];
        } else {
            return weighted_loglik[0]+weighted_loglik[1];
        }
    } 
}

#undef sq

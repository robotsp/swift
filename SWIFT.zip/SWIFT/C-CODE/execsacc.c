/*------------------------------------------------------
 Execute saccade
 (Version 1.0, 05-AUG-02)
 (Version 2.0, 12-NOV-03)
 (Version 2.1, 06-APR-16) 
 -----------------------------------------------------*/

/*
 *kpos             == letter position in sentence
 *next_tar         == word number of intended saccade target
 view[(*next_tar)] == OVP of intended saccade target
 knew              == actual letter position after saccade with distance-dependent error
 */


double execsacc(double *kpos,int *k,int *next_tar,double *view,
                double *border,int *len,int NW,double *s1,double *s2,
                double *r1,double *r2,long *seed,int OUTPUT, int fitting, double upcoming_letter_pos)
{
    FILE     *fout;
    double   dist, d, dx, knew, sd, sre, out;
    int      l, w, type;
    
    dist = view[(*next_tar)] - (*kpos);
    
    /* 1. Determine saccade type */
    /*    forward saccade */
    type = 1;
    /*    skipping saccade   */
    if ( (*next_tar)>(*k)+1 )  type = 2;
    /*    refixation saccade */
    if ( (*k)==(*next_tar) )  {
        if ( dist>=0.0 )
            type = 3;  /* forward refixation */
        else
            type = 4; /* backward refixation */
    }
    /*    regressive saccade */
    if ( (*k)>(*next_tar) )  type = 5;
    
    /*    output    */
    if ( OUTPUT==1 )  {
        if ( (*k)>1 && (*k)<NW )  {
            fout = fopen("sacc.stat","a");
            fprintf(fout,"%d\t%d\t%lf\t%d\t%lf\t%lf\t%lf\t%d\n",type,*k,*kpos,*next_tar,view[*next_tar],border[*k],border[(*k)-1],len[*k]);
            fclose(fout);
        }
    }
    
    /* 2. Oculomotor parameters */
    d = fabs(dist);
    sd = s1[type] + s2[type]*d;   /* oculomotor noise    */
    sre = r1[type] - r2[type]*d;  /* saccade range error */
    
    if ( fitting <= 0 ) {
        /* 3. Compute landing position */
        knew = view[(*next_tar)] + sre + sd*gasdev(seed);
        out = knew - view[(*next_tar)]; // saccadic error
        for ( w=1, l=1; w<=NW-1; w++ )  if ( knew >= border[w] ) l++;
        if ( knew >= border[NW] )  knew = border[NW]-0.5;
        if ( knew<=1.0 )  knew = 1.5;
        (*kpos) = knew;
        (*k) = l;
        
    } else {        
        dx = upcoming_letter_pos - (view[(*next_tar)] + sre);
        out = 1.0/(sqrt(2.0*M_PI)*sd)*exp(-((dx*dx)/(2.0*sd*sd))); // P(landing_position|intended_word)
    }
    return out;
}


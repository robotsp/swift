
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include <limits.h>

// NOTE: long is 8 bytes long, short is 2 bytes long
// conversion of long* to short[] pointer is safe
// technically, long* would be equivalent to short[4]
// but we only use the first 3 (48bits) for *rand48 functions
// the 4th short (7th and 8th byte of long) is ignored

void longto48bit(long a, unsigned short *b) {
	unsigned long c = (unsigned long) a;
	unsigned short i;
	for(i=0;i<3;i++) {
		b[i] = c % USHRT_MAX;
		c /= USHRT_MAX;
	}
}

long longfrom48bit(unsigned short *b) {
	unsigned long c = 0, base = 1;
	unsigned short i;
	for(i=0;i<3;i++) {
		c += base * b[i];
		base *= USHRT_MAX;
	}
	return (long) c;
}

double randouble(long *seed) {
	unsigned short sseed[3];
	longto48bit(*seed, sseed);
	double ret = erand48(sseed);
	*seed = longfrom48bit(sseed);
	return ret;
}

float ranfloat(long *seed) {
	float retval = (float) randouble(seed);
	// conversion of double to float can possibly cause retval to be outside [0.0, 1.0)
	if(retval<=0.0f)
		return 0.0f;
	else if(retval>=1.0f-FLT_EPSILON)
		return 1.0f-FLT_EPSILON;
	else
		return retval;
}

float ran1(long *seed) {
	return ranfloat(seed);
}

long ranlong(long *seed) {
	unsigned short sseed[3];
	longto48bit(*seed, sseed);
	long ret = jrand48(sseed);
	*seed = longfrom48bit(sseed);
	return ret;
}

unsigned long ranulong(long *seed) {
	unsigned short sseed[3];
	longto48bit(*seed, sseed);
	unsigned long ret = nrand48(sseed);
	*seed = longfrom48bit(sseed);
	return ret;
}


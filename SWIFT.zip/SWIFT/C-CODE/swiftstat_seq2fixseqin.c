
#include <stdio.h>
#include <libgen.h>

#include "swiftstat_api.c"

int main(int argc, char *argv[])
{
	if(argc<=1) {
		// no arguments have been passed -> just show usage
		char *appname = basename(argv[0]);
		fprintf(stderr, "SWIFT model simulation output to fixseqin conversion tool (SWIFT v%d.%d, API v%d.%d)\n", SWIFT_VERSION_MAJOR, SWIFT_VERSION_MINOR, SWIFT_API_VERSION_MAJOR, SWIFT_API_VERSION_MINOR);
		fprintf(stderr, "Usage: %s inputfile [outputfile or '-' [subject number]]\n", appname);
		fprintf(stderr, "Ex. #1: %s ../SIM/seq.dat                              (output in stdout)\n", appname);
		fprintf(stderr, "        %s ../SIM/seq.dat -                            (equivalent)\n", appname);
		fprintf(stderr, "Ex. #2: %s ../SIM/seq.dat ../DATA/fixseqin.dat         (output in file)\n", appname);
		fprintf(stderr, "        %s ../SIM/seq.dat > ../DATA/fixseqin.dat       (pipe equivalent)\n", appname);
		return 1;
	}
	// at least one argument --> 1st argument is infile
	FILE *fin = fopen(argv[1], "r");
	if(fin==NULL) {
		fprintf(stderr, "Input file '%s' could not be opened!\n", argv[1]);
		return 1;
	}
	FILE *fout;
	if(argc<=2||!strcmp("-",argv[2])) {
		// if no 2nd argument or 2nd argument is "-" --> output into stdout
		fout = stdout;
	}else{
		// if 2nd argument given and is not "-" --> create output file there
		fout = fopen(argv[2], "w");
		if(fout==NULL) {
			fclose(fin);
			fprintf(stderr, "Output file '%s' could not be opened!\n", argv[2]);
			return 1;
		}
	}

	// call API function --> returns 0 on success or a negative number if an error occurred
	const int success = swift_seq2fixseqin_fptr(fin, fout);

	fclose(fin);
	if(fout != stdout) fclose(fout);

	return success; // will be 0 if API call was successful
}


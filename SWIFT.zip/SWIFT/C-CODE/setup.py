from numpy.distutils.core import setup, Extension
import os, platform


if platform.system() == "Darwin":
	# use static linking to make OpenMP work on Mac
	module1 = Extension('swift', sources = ['swiftstat7_py.c'], extra_compile_args=['-fopenmp'], extra_link_args=['-fopenmp','-static'])
elif platform.system() == "Linux":
	module1 = Extension('swift', sources = ['swiftstat7_py.c'], extra_compile_args=['-fopenmp'], extra_link_args=['-fopenmp'])
#module1 = Extension('swift', sources = ['swiftstat7_py.c'])


setup (name = 'swiftstat7',
       version = '0.1',
       description = 'Python module interface to SWIFT API',
       ext_modules = [module1])


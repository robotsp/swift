

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/stat.h>

#include "func/nrutil.c"
#include "func/rangen.c"
#include "func/gasdev.c"
#include "func/indexx.c"

#include "procrate.c"
#include "execsacc.c"
#include "selectar.c"
#include "epaKDE.c"
#include "likPDA.c"
#include "model_main.c"

#ifndef DISABLE_THREADS
    #ifdef _OPENMP
        #include <omp.h>
        #ifndef ENABLE_OPENMP
        #define ENABLE_OPENMP
        #endif
    #else
        #ifdef _POSIX_VERSION
            #include <pthread.h>
            #ifndef ENABLE_POSIX
            #define ENABLE_POSIX
            #endif
        #else
            #define DISABLE_THREADS
        #endif
    #endif
#endif

#define N_LOGLIKS 3
#define SWIFT_VERSION_MAJOR 12
#define SWIFT_VERSION_MINOR 1
#define SWIFT_API_VERSION_MAJOR 1
#define SWIFT_API_VERSION_MINOR 0

typedef struct {
    char *style;
    char *plain;
    char *markdown;
} swift_citation;

static swift_citation swift_citations[] = {
    {
        "AMA",
        "Engbert R, Nuthmann A, Richter E, Kliegl R. SWIFT: A Dynamical Model of Saccade Generation During Reading. \e[3mPsychological Review\e[23m [serial online]. October 2005;112(4):777-813.",
        "Engbert R, Nuthmann A, Richter E, Kliegl R. SWIFT: A Dynamical Model of Saccade Generation During Reading. *Psychological Review* [serial online]. October 2005;112(4):777-813."
    },
    {
        "APA",
        "Engbert, R., Nuthmann, A., Richter, E. M., & Kliegl, R. (2005). SWIFT: A Dynamical Model of Saccade Generation During Reading. \e[3mPsychological Review, 112\e[23m, 777-813. doi:10.1037/0033-295X.112.4.777",
        "Engbert, R., Nuthmann, A., Richter, E. M., & Kliegl, R. (2005). SWIFT: A Dynamical Model of Saccade Generation During Reading. *Psychological Review, 112*, 777-813. doi:10.1037/0033-295X.112.4.777"
    },
    {
        "Chicago",
        "Engbert, Ralf, Antje Nuthmann, Eike M. Richter, and Reinhold Kliegl. 2005. “SWIFT: A Dynamical Model of Saccade Generation During Reading.” \e[3mPsychological Review\e[23m 112, no. 4: 777-813.",
        "Engbert, Ralf, Antje Nuthmann, Eike M. Richter, and Reinhold Kliegl. 2005. “SWIFT: A Dynamical Model of Saccade Generation During Reading.” *Psychological Review* 112, no. 4: 777-813."
    },
    {
        "Harvard",
        "Engbert, R, Nuthmann, A, Richter, E, & Kliegl, R 2005, ‘SWIFT: A Dynamical Model of Saccade Generation During Reading’, \e[3mPsychological Review\e[23m, 112, 4, pp. 777-813",
        "Engbert, R, Nuthmann, A, Richter, E, & Kliegl, R 2005, ‘SWIFT: A Dynamical Model of Saccade Generation During Reading’, *Psychological Review*, 112, 4, pp. 777-813"
    },
    {
        "MLA",
        "Engbert, Ralf, et al. “SWIFT: A Dynamical Model of Saccade Generation during Reading.” \e[3mPsychological Review\e[23m, vol. 112, no. 4, Oct. 2005, pp. 777-813. \e[3mAPA PsycNET\e[23m, doi:10.1037/0033-295X.112.4.777.",
        "Engbert, Ralf, et al. “SWIFT: A Dynamical Model of Saccade Generation during Reading.” *Psychological Review*, vol. 112, no. 4, Oct. 2005, pp. 777-813. *APA PsycNET*, doi:10.1037/0033-295X.112.4.777."
    },
    {
        "BibTex",
        "@article{Engbert2005,\n  Author = {Engbert, Ralf and Nuthmann, Antje and Richter, Eike M. and Kliegl, Reinhold},\n  ISSN = {0033-295X},\n  Journal = {Psychological Review},\n  Volume = {112},\n  Number = {4},\n  Pages = {777-813},\n  Title = {SWIFT: A Dynamical Model of Saccade Generation During Reading.},\n  Year = {2005},\n  DOI = {10.1037/0033-295X.112.4.777}\n}",
        0
    },
    {NULL}
};

swift_citation *swift_find_citation_style(char *style_name) {
    size_t i;
    for(i=0;swift_citations[i].style!=NULL;i++)
        if(!strcmp(swift_citations[i].style, style_name))
            return &swift_citations[i];
    return NULL;
}

typedef struct {
    char msg[500];
    int code;
} swift_error;

static swift_error *swift_last_error = NULL;

static swift_error *swift_throw_error(int code, char* fmtstr, ...) { // create (not "throw") error message
    swift_error *err = malloc(sizeof(swift_error));
    va_list argptr;
    va_start(argptr, fmtstr);
    vsprintf(err->msg, fmtstr, argptr);
    va_end(argptr);
    err->code = code;
    return err;
}

static int swift_set_error(swift_error *err) {
    if(swift_last_error!=NULL)
        free(swift_last_error);
    swift_last_error = err;
    #ifdef SWIFT_ERR_EXIT
    exit(err->code);
    #endif
    return err->code;
}

swift_error *swift_get_error() { // "get" error
    return swift_last_error;
}

typedef struct {
    unsigned short nos, iter, npar;
    int *slen, *wlen;
    unsigned int totnw;
    double *wfreq, *wpred, *s1, *s2, *r1, *r2, **par;
    long seed;
} swift_model;

typedef struct {
    int **fixseqs;
    unsigned int Nfix;
    unsigned short Ntrials;
    double *flet;
} swift_data;

typedef struct {
    int Nsubsets;
    swift_data **subsets;
} swift_data_subsets;

void free_swift_model(swift_model *m) {
    free_dmatrix(m->par,1,29,1,2);
    free_ivector(m->slen,1,m->nos);
    free_dvector(m->wfreq,1,m->totnw);
    free_ivector(m->wlen,1,m->totnw);
    free_dvector(m->wpred,1,m->totnw);
    free_dvector(m->s1,1,4);
    free_dvector(m->s2,1,4);
    free_dvector(m->r1,1,4);
    free_dvector(m->r2,1,4);
    free(m);
}

void free_swift_data(swift_data *d) {
    free_imatrix(d->fixseqs,1,d->Nfix,1,10);
    free_dvector(d->flet,1,d->Nfix);
    free(d);
}

void free_swift_data_subsets(swift_data_subsets *d) {
    int i;
    for(i=0;i<d->Nsubsets;i++) {
        free_swift_data(d->subsets[i]);
    }
    free(d->subsets);
    free(d);
}

typedef struct {
    unsigned int major, minor;
} version;

const version swift_version = {SWIFT_VERSION_MAJOR, SWIFT_VERSION_MINOR};

const version swift_api_version = {SWIFT_API_VERSION_MAJOR, SWIFT_API_VERSION_MINOR};

static char *swift_parameter_names[] = {"delta0","delta1","beta","msac","h","ppf","iota","msac0","refix","misfac","kappa0","kappa1","proc","decay","theta","gamma","tau_l","tau_n","tau_ex","alpha","asym","eta","aord","cord","lord","nord","xord","minact","misprob","omn_fs1","omn_fs2","omn_sk1","omn_sk2","omn_frf1","omn_frf2","omn_brf1","omn_brf2","omn_rg1","omn_rg2","sre_fs1","sre_fs2","sre_sk1","sre_sk2","sre_frf1","sre_frf2","sre_brf1","sre_brf2","sre_rg1","sre_rg2",NULL};
static char *swift_discrete_parameter_names[] = {"runs",NULL};

int get_parameter_id(char *parname)
{
    unsigned int i;
    for(i=0;swift_parameter_names[i]!=NULL;i++)
        if(!strcmp(parname, swift_parameter_names[i]))
            return i+1;
    return -1;
}

int get_discrete_parameter_id(char *parname)
{
    unsigned int i;
    for(i=0;swift_discrete_parameter_names[i]!=NULL;i++)
        if(!strcmp(parname, swift_discrete_parameter_names[i]))
            return i+1;
    return -1;
}

char *get_parameter_name(unsigned int parid) {
    return swift_parameter_names[parid-1];
}

char *get_discrete_parameter_name(unsigned int parid) {
    return swift_discrete_parameter_names[parid-1];
}

int swift_set_parameter(int parid, double ddum, swift_model *m)
{
    // parameter nrs. 1-29 are stored in par[...], parameters 30-49 are stored in r1, r2, s1 and s2
    if(parid >= 1 && parid <= 29) m->par[parid][1] = ddum;
    else if(parid == 30 /*  omn_fs1 */) m->s1[1] = ddum;
    else if(parid == 31 /*  omn_fs2 */) m->s2[1] = ddum;
    else if(parid == 32 /*  omn_sk1 */) m->s1[2] = ddum;
    else if(parid == 33 /*  omn_sk2 */) m->s2[2] = ddum;
    else if(parid == 34 /* omn_frf1 */) m->s1[3] = ddum;
    else if(parid == 35 /* omn_frf2 */) m->s2[3] = ddum;
    else if(parid == 36 /* omn_brf1 */) m->s1[4] = ddum;
    else if(parid == 37 /* omn_brf2 */) m->s2[4] = ddum;
    else if(parid == 38 /*  omn_rg1 */) m->s1[5] = ddum;
    else if(parid == 39 /*  omn_rg2 */) m->s2[5] = ddum;
    else if(parid == 40 /*  sre_fs1 */) m->r1[1] = ddum;
    else if(parid == 41 /*  sre_fs2 */) m->r2[1] = ddum;
    else if(parid == 42 /*  sre_sk1 */) m->r1[2] = ddum;
    else if(parid == 43 /*  sre_sk2 */) m->r2[2] = ddum;
    else if(parid == 44 /* sre_frf1 */) m->r1[3] = ddum;
    else if(parid == 45 /* sre_frf2 */) m->r2[3] = ddum;
    else if(parid == 46 /* sre_brf1 */) m->r1[4] = ddum;
    else if(parid == 47 /* sre_brf2 */) m->r2[4] = ddum;
    else if(parid == 48 /*  sre_rg1 */) m->r1[5] = ddum;
    else if(parid == 49 /*  sre_rg2 */) m->r2[5] = ddum;
    else {
        fprintf(stderr, "WARNING: Parameter nr. %d is out of range (1<=x<=49)!\n", parid);
        return 0;
    }
    return 1;
}

double swift_get_parameter(int parid, swift_model *m)
{
    // parameter nrs. 1-29 are stored in par[...], parameters 30-49 are stored in r1, r2, s1 and s2
    if(parid >= 1 && parid <= 29) return m->par[parid][1];
    else if(parid == 30 /*  omn_fs1 */) return m->s1[1];
    else if(parid == 31 /*  omn_fs2 */) return m->s2[1];
    else if(parid == 32 /*  omn_sk1 */) return m->s1[2];
    else if(parid == 33 /*  omn_sk2 */) return m->s2[2];
    else if(parid == 34 /* omn_frf1 */) return m->s1[3];
    else if(parid == 35 /* omn_frf2 */) return m->s2[3];
    else if(parid == 36 /* omn_brf1 */) return m->s1[4];
    else if(parid == 37 /* omn_brf2 */) return m->s2[4];
    else if(parid == 38 /*  omn_rg1 */) return m->s1[5];
    else if(parid == 39 /*  omn_rg2 */) return m->s2[5];
    else if(parid == 40 /*  sre_fs1 */) return m->r1[1];
    else if(parid == 41 /*  sre_fs2 */) return m->r2[1];
    else if(parid == 42 /*  sre_sk1 */) return m->r1[2];
    else if(parid == 43 /*  sre_sk2 */) return m->r2[2];
    else if(parid == 44 /* sre_frf1 */) return m->r1[3];
    else if(parid == 45 /* sre_frf2 */) return m->r2[3];
    else if(parid == 46 /* sre_brf1 */) return m->r1[4];
    else if(parid == 47 /* sre_brf2 */) return m->r2[4];
    else if(parid == 48 /*  sre_rg1 */) return m->r1[5];
    else if(parid == 49 /*  sre_rg2 */) return m->r2[5];
    else {
        fprintf(stderr, "WARNING: Parameter nr. %d is out of range (1<=x<=49)!\n", parid);
        return 0.0;
    }
}

int swift_set_discrete_parameter(int parid, int idum, swift_model *m)
{
    // parameter nrs. 1-29 are stored in par[...], parameters 30-49 are stored in r1, r2, s1 and s2
    if(parid == 1) m->iter = idum;
    else {
        fprintf(stderr, "WARNING: Parameter nr. %d is out of range (1<=x<=3)!\n", parid);
        return 0;
    }
    return 1;
}

int swift_get_discrete_parameter(int parid, swift_model *m)
{
    // parameter nrs. 1-29 are stored in par[...], parameters 30-49 are stored in r1, r2, s1 and s2
    if(parid == 1) return m->iter;
    else {
        fprintf(stderr, "WARNING: Parameter nr. %d is out of range (1<=x<=3)!\n", parid);
        return 0;
    }
}

int swift_seq2fixseqin_fptr(FILE *fin, FILE *fout) {
    char buf[1000]; // buffer for infile line
    char fieldbuf[50]; // buffer for a field (column content in infile line)
    char line[10][sizeof(fieldbuf)/sizeof(char)]; // buffer for outfile line (10 columns)
    double t0_this;

    // mapping of infile columns to oufile columns (<0: ignore column, >=0: write into this outfile column)
    // moreover, the length of this array defines the expected column count per infile line (warning will be output if length doesn't match)
    static int mapping[] = {9, 0, 1, 2, 3, -1, -1, -1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, 4};

    unsigned int i /*char pos within infile line*/, j /*char pos within field buffer*/, k /*field no.*/, w=0, line_counter=0;

    // set fixed fields (will remain constant)
    sprintf(line[6], "0");
    sprintf(line[7], "0");
    sprintf(line[8], "0");

    while(fgets(buf, sizeof(buf), fin)!=NULL) {
        // new line: reset j (char pos. within field buf) and k (field no.)
        j = 0;
        k = 0;
        line_counter++;
        for(i=0;i<sizeof(buf)&&(i==0||buf[i-1]!=0);i++) {
            if(buf[i]==' '||buf[i]=='\n'||buf[i]=='\r'||buf[i]=='\t'||buf[i]==0) {
                // hitting end of line, end of buffer, or whitespace
                if(j>0) {
                    // field buffer is not empty, so add its contents to outfile line
                    fieldbuf[j]=0;
                    if(mapping[k]>=0) {
                        // col #k in infile is to be written into col# mapping[k] in outfile
                        if(mapping[k]==4) {
                            // if field no. == 4 (t_abs)
                            sscanf(fieldbuf, "%lf", &t0_this);
                        } else {
                            sprintf(line[mapping[k]], "%s", fieldbuf);
                        }
                    }
                    // reset field buffer pos. to 0 (overwrite with next read char)
                    j=0;
                    // increment field no.
                    k++;
                }else{
                    // empty (multiple whitspaces) -> do nothing
                }
            }else{
                // copy char from infile line to field buffer and increment field buffer char pos.
                fieldbuf[j] = buf[i];
                j++;
            }
        }

        if(!strcmp(line[5], "2")) {
            // last fixation in sequence (no next saccade) -> col #5 = 0
            sprintf(line[4], "%d", 0);
        }else{
            // at this point, the whole line has been processed except for col #5 (value temporarily saved as double t0_this)
            double t0_next;
            unsigned int fixdur;
            long int pos;
            // parse col #4 as fixation duration
            sscanf(line[3], "%u", &fixdur);
            pos = ftell(fin); // -> current position is beginning of next line -> we want to return there again!
            // skip first 19 columns of next line
            for(i=0;i<19;i++) fscanf(fin, "%*s");
            // parse col #20 as double t0_next
            fscanf(fin, "%lf", &t0_next);
            // return to beginning of line
            fseek(fin, pos, SEEK_SET);
            // save difference between end of fixation (t0_this+fixdur) and start of next fixation (t0_next) as saccade duration (col #5)
            sprintf(line[4], "%u", (unsigned int) (t0_next-t0_this-fixdur));
        }

        if(k != sizeof(mapping)/sizeof(unsigned int)) {
            fprintf(stderr, "\tLine #%u too short or too long (%u columns but expected %lu)! Missing contents are copied from previous line and overflow contents are truncated.\n", line_counter, k, sizeof(mapping)/sizeof(unsigned int));
        }

        // update col #6 (fixation no. within sequence)
        if(!strcmp(line[5], "1")) {
            // begin of fixation sequence -> reset w (fixation no. within sequence)
            w=1;
        }else{
            w++;
        }
        // set fixation no. within sequence
        sprintf(line[8], "%u", w);

        // write line into outfile
        for(i=0;i<10;i++) {
            if(i>0) fprintf(fout, "\t");
            fprintf(fout, "%s", line[i]);
        }
        fprintf(fout, "\n");
    }

    fclose(fin);
    fclose(fout);
    return 0;
}

int swift_seq2fixseqin(char *seqFile, char *fixseqFile) {
    /*
        This reads the seq_*.dat infile (specified by seqFile) and converts its contents
        into a fixseqin_*.dat file (readable as model input)
    */

    FILE *fin, *fout;
    swift_error *err = NULL;
    fin = fopen(seqFile, "r");
    if(fin==NULL) {
        err = swift_throw_error(-1, "%s could not be found and opened for reading.", seqFile);
        return swift_set_error(err);
    }
    fout = fopen(fixseqFile, "w");
    if(fin==NULL) {
        err = swift_throw_error(-2, "%s could not be opened for writing.", fixseqFile);
        return swift_set_error(err);
    }

    return swift_seq2fixseqin_fptr(fin, fout);

}

/*
    This loads model parameters and configuration from environmentPath, parmPath, corpusFile
*/
int swift_load_model(char *environmentPath, char *parmPath, char *corpusFile, long seed, swift_model **dat, int verbose)
{
    FILE *fin;
    int cnt, nw, ans, w, i, s, now;
    double ddum;
    char tmp[200], parname[50];

    swift_error *err;

    swift_model *m = (swift_model*) malloc(sizeof(swift_model));

    m->seed = seed;

        /* -----------------------
         SIMULATION PARAMETERS
         ----------------------- */
    if(verbose) printf("\t1. Simulation parameters:\n");
    sprintf(tmp, "%s/swiftstat.inp", environmentPath);
    fin = fopen( tmp, "r" );
    if ( fin == NULL ) {
        err = swift_throw_error(-1, "No %s found.\n", tmp);
        return swift_set_error(err);
    }

    fscanf( fin, "%s%hu", parname, &m->iter ); // number of iterations
    if(verbose) printf( "\t%s\t = %d\n", parname, m->iter );

    fclose(fin);


    /* ------------------
     MODEL PARAMETERS
     ------------------- */

    m->par = dmatrix(1,34,1,2);
    m->s1  = dvector(1,5);
    m->s2  = dvector(1,5);
    m->r1  = dvector(1,5);
    m->r2  = dvector(1,5);



    fin = fopen(parmPath,"r");
    if ( fin == NULL ) {
        printf("\n\tNo %s found.\n", parmPath);
        return -1;
    } else if(verbose) printf("\n\t2. Model parameters: (%s)\n",parmPath);

    cnt = 2;
    m->npar = 0;
    while ( cnt==2 )  {
        cnt = fscanf(fin,"%s%lf",parname,&ddum);
        if ( cnt==2 ) {      // NOTE: parameter-number pairing MUST be the same as in model_main6.c !!!

            if(swift_set_parameter(get_parameter_id(parname), ddum, m)) {
                m->npar++;
            }

            if ((strncmp(parname, "omn",3) != 0) && (strncmp(parname, "sre",3) != 0) && verbose) {
                printf("\t  %10s = %f\n", parname, ddum);
            }
        }
    }
    fclose(fin);

    if ( m->npar != 49 ) {
        printf("\tNot enough parameters in '%s'. Stopping SWIFT...\n",parmPath);
        return -1;
    } else (m->npar)-=20; // substract parameters not stored in par[][]


    /* --------------------------
     SACCADE ERROR PARAMETERS
     -------------------------- */
    if (verbose) {
        printf("\n\t3. Saccade error parameter:\n");
        for ( i=1; i<=5; i++ ) printf("\t   noise (Type %d): \t%.3f\t%.3f\n",i,m->s1[i],m->s2[i]);
        for ( i=1; i<=5; i++ ) printf("\t   SRE   (Type %d): \t%.3f\t%.3f\n",i,m->r1[i],m->r2[i]);
    }


    /* -------------------------
     TEXT CORPUS
     ------------------------- */

    /*  reading word list  */
    m->nos = 0;
    m->totnw = 0;
    fin = fopen(corpusFile,"r");
    if (fin == NULL) {
        err = swift_throw_error(-1, "Wrong corpus specified! Expected file: %s", corpusFile);
        return swift_set_error(err);
    }
    ans = 1;
    while ( ans!=EOF ) {
        ans = fscanf(fin, "%d", &nw);
        if ( ans!=EOF ) {
            m->nos++;
            m->totnw += nw;
            for ( w=1; w<=nw; w++ ) {
                fgets(tmp, sizeof(tmp), fin);
                //fscanf(fin,"%d%lf%d",&idum,&ddum,&idum);
            }
        }
    }

    fclose(fin);



    if(verbose) printf("\n\t4. Empirical data: (%s)\n", corpusFile);
    if(verbose) printf(  "\t   %d sentences, %d words\n",m->nos,m->totnw);
    m->slen = ivector(1,m->nos);          // sentence length in words
    m->wfreq = dvector(1,m->totnw);         // frequencies
    m->wlen = ivector(1,m->totnw);        // letters per word
    m->wpred = dvector(1,m->totnw);        // predictabilities
    fin = fopen(corpusFile,"r");
    for ( s=1; s<=m->nos; s++ ) {
        fscanf(fin,"%d",&nw);
        m->slen[s] = nw;
        for ( i=1, now=0; i<s; i++ )  now += m->slen[i];
        for ( w=1; w<=nw; w++ ) {
            fscanf(fin,"%d%lf", &m->wlen[now+w], &m->wfreq[now+w]);
            m->wpred[now+w] = 0; // needs initialisation!
        }
    }
    fclose(fin);

    *dat = m;

    return 0;
}


int swift_subset_data(swift_data *d, int n, swift_data_subsets **dat, int verbose) {
    const int ncol = 10;
    swift_data_subsets *s = (swift_data_subsets*) malloc(sizeof(swift_data_subsets));
    unsigned int fixseqs_loads[d->Ntrials];
    unsigned int fixseqs_offsets[d->Ntrials];
    unsigned short fixseqs_toassign[d->Ntrials];
    unsigned int subset_loads[n];
    unsigned int subset_lengths[n];
    unsigned int subset_assignments[n][d->Ntrials-n+1]; // each subset can only hold up to Ntrials-Nsubsets+1 trials beacuse each other subset (Nsubset-1) will receive at least one trial

    s->Nsubsets = n;
    int n_fixseqs_toassign = d->Ntrials;
    int i, j, c=-1, longest_fixseq, shortest_list;
    for(i = 1; i <= d->Nfix; i++) {
        if(i == 1 || d->fixseqs[i][6] == 1) {
            // The first fixation of each sequence begins with 1 in column 6
            c++;
            fixseqs_offsets[c] = i;
            fixseqs_loads[c] = 0;
            fixseqs_toassign[c] = 1;
        }
        fixseqs_loads[c]++;
    }

    // initialize subsets
    for(i = 0; i < n; i++) {
        subset_loads[i] = 0;
        subset_lengths[i] = 0;
        // no need to initialize subset_assignments
    }

    while(n_fixseqs_toassign > 0) {
        for(i=0,longest_fixseq=-1;i<d->Ntrials;i++) {
            if(!fixseqs_toassign[i]) continue;
            if(longest_fixseq == -1 || fixseqs_loads[i] > fixseqs_loads[longest_fixseq]) longest_fixseq=i;
        }
        for(i=1,shortest_list=0;i<n;i++) {
            if(subset_loads[i] < subset_loads[shortest_list]) shortest_list = i;
        }
        for(i=0;i<subset_lengths[shortest_list];i++) {
            if(d->fixseqs[fixseqs_offsets[subset_assignments[shortest_list][i]]][1]>d->fixseqs[fixseqs_offsets[longest_fixseq]][1]) break;
        }
        for(j=subset_lengths[shortest_list]-1;j>=i;j--) {
            subset_assignments[shortest_list][j+1] = subset_assignments[shortest_list][j];
        }
        subset_assignments[shortest_list][i] = longest_fixseq;
        subset_loads[shortest_list]+=fixseqs_loads[longest_fixseq];
        subset_lengths[shortest_list]++;
        fixseqs_toassign[longest_fixseq] = 0;
        n_fixseqs_toassign--;
    }

    int o, k, l;

    s->subsets = (swift_data**) calloc(n, sizeof(swift_data*));
    for(i=0;i<n;i++) {
        s->subsets[i] = (swift_data*) malloc(sizeof(swift_data));
        s->subsets[i]->Ntrials = subset_lengths[i];
        s->subsets[i]->Nfix = subset_loads[i];
        s->subsets[i]->fixseqs = imatrix(1, s->subsets[i]->Nfix, 1, ncol);
        s->subsets[i]->flet = dvector(1, s->subsets[i]->Nfix);
        if(verbose) printf("\t   Subset %d: Ntrials=%d, Nfix=%d\n", i, subset_lengths[i], subset_loads[i]);
        for(j=0,o=1;j<subset_lengths[i];j++) {
            int trial_id = subset_assignments[i][j];
            int trial_sno = d->fixseqs[fixseqs_offsets[trial_id]][1];
            int trial_nfix = fixseqs_loads[trial_id];
            if(verbose) printf("\t     trial %d with Nfix=%d\n", trial_sno, trial_nfix);
            for(k=0;k<fixseqs_loads[trial_id];k++,o++) {
                for(l=1;l<=ncol;l++)
                    s->subsets[i]->fixseqs[o][l] = d->fixseqs[fixseqs_offsets[trial_id]+k][l];
                s->subsets[i]->flet[o] = d->flet[fixseqs_offsets[trial_id]+k];
            }
        }
    }

    *dat = s;

    return 0;
}


/*
    This loads fixation sequences from file specified by fixseqName into fixseqs, flet, Nfix and Ntrials
*/
int swift_load_data(char *fixseqName, swift_data **dat, int verbose)
{
    int cnt, ans, line;
    FILE *fin;

    swift_data *d = (swift_data*) malloc(sizeof(swift_data));

    swift_error *err = NULL;

    // count lines
    fin = fopen(fixseqName, "r");
    if (fin == NULL) {
        err = swift_throw_error(-1, "Wrong fixation sequence specified! Expected file: %s", fixseqName);
        free(d);
        return swift_set_error(err);
    }


    d->Nfix=0;

    for(cnt=0,ans=1;ans!=EOF;) {
        ans=fgetc(fin);
        if(ans=='\n') {
            d->Nfix++;
            cnt=0;
        }
        else if(ans!=EOF) cnt++;
        else if(ans==EOF&&cnt>0) d->Nfix++;
    }

    //Don't close file but go back to beginning
    fseek(fin, 0, SEEK_SET);
    ans = 1;
    cnt = 0;
    d->fixseqs = imatrix(1,d->Nfix,1,10);
    d->flet = dvector(1,d->Nfix);
    d->Ntrials = 0;
    // read empirical data
    for (line = 1; ans!=EOF && line <= d->Nfix; line++) {
        //if(verbose) printf("\tParsing line %d...\n", line);
        ans=fscanf(fin, "%d%d%lf%d%d%d%d%d%d%d\n",
            &d->fixseqs[line][1],
            &d->fixseqs[line][2],
            &d->flet[line],
            &d->fixseqs[line][4],
            &d->fixseqs[line][5],
            &d->fixseqs[line][6],
            &d->fixseqs[line][7],
            &d->fixseqs[line][8],
            &d->fixseqs[line][9],
            &d->fixseqs[line][10]);
        if(ans == EOF) {
            break;
        }
        d->fixseqs[line][3] = floor(d->flet[line]);
        if(d->fixseqs[line][6] == 1) {
            d->Ntrials++;
        }
        if(ans < 10) {
            err = swift_throw_error(-3, "Invalid format after col# %d in line #%d (fixation sequence #%d)! Expected format: %%d%%d%%lf%%d%%d%%d%%d%%d%%d%%d", ans, line, d->Ntrials);
        }else if(d->fixseqs[line][6] < 0 || d->fixseqs[line][6] > 2) {
            err = swift_throw_error(-4, "Col #6 must be 1 (beginning of fixation sequence), 0 (body) or 2 (end). Invalid value %d occured at line #%d, fixation sequence #%d!", d->fixseqs[line][6], line, d->Ntrials);
        }else if(line==1 && d->fixseqs[line][6] != 1) {
            err = swift_throw_error(-5, "First line must be beginning of fixation sequence (col #6 == 1)!");
        }else if(line==d->Nfix && d->fixseqs[line][6] != 2) {
            err = swift_throw_error(-6, "Last line must be end of fixation sequence (col #6 == 2)!");
        }else if(d->flet[line] < -1.0) {
            err = swift_throw_error(-7,"Letter position (col #3) cannot be smaller than -1.0 (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][4] < 0) {
            err = swift_throw_error(-8, "Fixation duration (col #4) cannot be negative (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][5] < 0) {
            err = swift_throw_error(-9, "Saccade duration (col #5) cannot be negative (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][6] == 1 && line > 1 && d->fixseqs[line-1][6] != 2) {
            err = swift_throw_error(-10, "Start of fixation sequence (col #6 == 1) after missing end of sequence (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][6] == 2 && line > 1 && d->fixseqs[line-1][6] != 0 && d->fixseqs[line-1][6] != 1) {
            err = swift_throw_error(-11, "End of fixation sequence (col #6 == 2) after missing start or body of sequence (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][6] == 0 && line > 1 && d->fixseqs[line-1][6] == 2) {
            err = swift_throw_error(-12, "Body of fixation sequence (col #6 == 0) after missing start of sequence (error occured at line #%d)!", line);
        }else if(d->fixseqs[line][6] == 1 && line > 1 && line > 1 && d->fixseqs[line][1] < d->fixseqs[line-1][1]) {
            err = swift_throw_error(-13, "Fixation sequences must be ordered by sentence number (error occured at line #%d, fixation sequence #%d)!", line, d->Ntrials);
        }else if(d->fixseqs[line][6] != 1 && line > 1 && d->fixseqs[line][1] != d->fixseqs[line-1][1]) {
            err = swift_throw_error(-14, "Sentence no. (col #1) within fixation sequence must match (error occured at line #%d, fixation sequence #%d)!", line, d->Ntrials);
        }else if(d->fixseqs[line][6] != 1 && line > 1 && d->fixseqs[line][10] != d->fixseqs[line-1][10]) {
            err = swift_throw_error(-15, "Run no. (col #10) within fixation sequence must match (error occured at line #%d, fixation sequence #%d)!", line, d->Ntrials);
        }else if(d->fixseqs[line][6] == 1 && d->fixseqs[line][9] != 1) {
            err = swift_throw_error(-16, "First fixation in fixation sequence must start with col #9 == 1 (error occured at line #%d, fixation sequence #%d)!", line, d->Ntrials);
        }else if(d->fixseqs[line][6] != 1 && line > 1 && d->fixseqs[line][9] != d->fixseqs[line-1][9]+1) {
            err = swift_throw_error(-17, "Col #9 must contain running fixation no. within sequence (1..n) (error occured at line #%d, fixation sequence #%d)!", line, d->Ntrials);
        }
        if(err!=NULL) {
            fclose(fin);
            free_swift_data(d);
            return swift_set_error(err);
        }
    }

    if(line - 1 != d->Nfix) {
        fclose(fin);
        free_swift_data(d);
        err = swift_throw_error(-2, "Read in %d fixations but expected %d!", line-1, d->Nfix);
        return swift_set_error(err);
    }

    fclose(fin);

    *dat = d;

    return 0;

}

int swift_load_data_subsets(char *fixseqNamePattern, unsigned int Nsubsets, swift_data_subsets **dat, int verbose) {
    char tmp[300];
    swift_data_subsets *s = (swift_data_subsets*) malloc(sizeof(swift_data_subsets));
    s->subsets = (swift_data**) calloc(Nsubsets, sizeof(swift_data*));
    s->Nsubsets = 0;
    int i, success;
    for(i=0;i<Nsubsets;i++) {
        sprintf(tmp, fixseqNamePattern, i+1);
        if(verbose) printf("\tLoading subset <%d> from <%s>...\n", i+1, tmp);
        success = swift_load_data(tmp, &s->subsets[i], verbose);
        if(success != 0) {
            free_swift_data_subsets(s);
            return success;
        }
        s->Nsubsets++;
    }
    *dat = s;
    return 0;
}

// SWIFT in generative mode
void swift_model_main_generate(swift_model *mx, char *outputDir, char *outputName, int verbose) {
    double ddum[N_LOGLIKS]; // not needed for generative mode, dummy
    if(outputDir==NULL) outputDir = ".";
    char tmpdir[400];
    sprintf(tmpdir, "%s/swiftXXXXXX", P_tmpdir);
    tmpdir[strlen(tmpdir)+2] = 0;
    tmpdir[strlen(tmpdir)+1] = '/';
    mktemp(tmpdir);
    mkdir(tmpdir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    model_main(mx->nos,mx->slen,mx->wfreq,mx->wlen,mx->wpred,mx->iter,mx->s1,mx->s2,mx->r1,mx->r2,mx->par,mx->npar,&mx->seed,0,tmpdir,0,0,0,0,ddum,verbose); // simulation
    char path_omis7[PATH_MAX], path_osim[PATH_MAX], path_nsim[PATH_MAX], path_nmis7[PATH_MAX];
    sprintf(path_omis7, "%s_mis7.dat", tmpdir);
    sprintf(path_osim, "%s_seq.dat", tmpdir);
    sprintf(path_nmis7, "%s/mis7_%s.dat", outputDir, outputName);
    sprintf(path_nsim, "%s/seq_%s.dat", outputDir, outputName);
    rename(path_omis7, path_nmis7);
    rename(path_osim, path_nsim);
    rmdir(tmpdir);
}

// SWIFT in generative mode -> only specified sentence
void swift_model_main_generate_single(swift_model *mx, char *outputDir, char *outputName, int sno, int verbose) {
    double ddum[N_LOGLIKS]; // not needed for generative mode, dummy
    if(outputDir==NULL) outputDir = ".";
    char tmpdir[400];
    sprintf(tmpdir, "%s/swiftXXXXXX", P_tmpdir);
    tmpdir[strlen(tmpdir)+2] = 0;
    tmpdir[strlen(tmpdir)+1] = '/';
    mktemp(tmpdir);
    mkdir(tmpdir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    model_main(mx->nos,mx->slen,mx->wfreq,mx->wlen,mx->wpred,mx->iter,mx->s1,mx->s2,mx->r1,mx->r2,mx->par,mx->npar,&mx->seed,sno,tmpdir,0,0,0,0,ddum,verbose); // simulation
    char path_osim[PATH_MAX], path_nsim[PATH_MAX];
    sprintf(path_osim, "%s_seq.dat", tmpdir);
    sprintf(path_nsim, "%s/seq_%s.dat", outputDir, outputName);
    rename(path_osim, path_nsim);
    rmdir(tmpdir);
}

// lowest level LL-eval-function: calls model_main
static void swift_model_main_eval_single(swift_model *mx, swift_data *dx, long *seed, double *loglik, char *outputFile) {
    // if seed was not passed (only if no parallelisation), default to model's internal random seed (mx->seed)
    if(seed == NULL)
        seed = &mx->seed;
    // set the first element of loglik to the return value of model_main (composite likelihood) and write partial likelihoods into same array starting at index 1 (&loglik[1])
    loglik[0] = model_main(mx->nos,mx->slen,mx->wfreq,mx->wlen,mx->wpred,mx->iter,mx->s1,mx->s2,mx->r1,mx->r2,mx->par,mx->npar,seed,0,outputFile,dx->fixseqs,dx->flet,1,dx->Nfix,&loglik[1],0);
}

// calls model_main "iter" times; sequentially
void swift_model_main_eval(swift_model *mx, swift_data *dx, long *seed, double *loglik, char *outputFile) {
    // NOTE: This is working sequentially, not in parallel!
    // if seed was not passed, default to model's internal random seed (mx->seed)
    swift_model_main_eval_single(mx, dx, seed, loglik, outputFile);
    if(mx->iter > 1) {
        double tmp[N_LOGLIKS];
        int i, j;
        for(i=1;i<mx->iter;i++) {
            swift_model_main_eval_single(mx, dx, seed, tmp, outputFile);
            for(j=0;j<N_LOGLIKS;j++) loglik[j] += tmp[j];
        }
        for(j=0;j<N_LOGLIKS;j++) loglik[j] /= (double) mx->iter;
    }
}

#ifndef DISABLE_THREADS

// compiler directives
#ifndef ENABLE_OPENMP
#ifdef ENABLE_POSIX
// OpenMP has priority over POSIX and we don't need this if we only call OpenMP routines
struct swift_model_main_eval_pthread_args {
    swift_model *mx;
    swift_data *dx;
    pthread_mutex_t lock;
    char *outputFile;
    double *loglik;
    long *seed;
};
void swift_model_main_eval_pthread(void *targs) {
    struct swift_model_main_eval_pthread_args *args = (struct swift_model_main_eval_pthread_args*) targs;
    swift_model_main_eval(args->mx, args->dx, args->seed, args->loglik, args->outputFile);
    pthread_exit(NULL);
}
#endif
#endif

// calls model_main "iter" times; parallely
void swift_model_main_eval_subsets(swift_model *mx, swift_data_subsets *dx, double *loglik, char *outputFile) {

    if(dx->Nsubsets==1) {
        // there is only one subset, so we don't need all of that parallel stuff
        swift_model_main_eval(mx, dx->subsets[0], NULL, loglik, outputFile);
        return;
    }

    int i, j;

    for(i=0;i<N_LOGLIKS;i++) {
        loglik[i] = 0.0; // initialize
    }

    // parallelize with open-mp
    #ifdef ENABLE_OPENMP

    double retvals[N_LOGLIKS];
    long seeds[dx->Nsubsets*mx->iter]; // create as many seeds as (subsets * runs)
    for(i=0;i<dx->Nsubsets*mx->iter;i++)
        seeds[i] = ranlong(&mx->seed);
    // "pragma parallel for" parallelizes upcoming for loop
    #pragma omp parallel for shared(loglik, seeds, mx, dx) private(retvals, i, j)
    for(i=0;i<dx->Nsubsets*mx->iter;i++) {
        swift_model_main_eval_single(mx, dx->subsets[i%dx->Nsubsets], &seeds[i], retvals, outputFile);
        for(j=0;j<N_LOGLIKS;j++) {
            #pragma omp atomic update
            loglik[j] += retvals[j] / (double) mx->iter;
        }
    }

    #else
    // parallelize with posix
    #ifdef ENABLE_POSIX

    unsigned int nthreads = dx->Nsubsets;
    long seeds[nthreads];
    for(i=0;i<nthreads;i++)
        seeds[i] = ranlong(&mx->seed);
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
    double retvals[N_LOGLIKS*(nthreads-1)];
    pthread_t threads[nthreads-1];
    struct swift_model_main_eval_pthread_args args[nthreads-1];

    int rc;
    //printf("Start %d pthreads \n", dx->Nsubsets);
    for(i=0; i<nthreads-1; i++){
        args[i].mx = mx;
        // only subsets 1..n are evaluated in parallel background threads
        args[i].dx = dx->subsets[i+1];
        args[i].loglik = &retvals[i*N_LOGLIKS];
        args[i].seed = &seeds[i+1];
        args[i].outputFile = outputFile;
        rc = pthread_create(&threads[i], &attr, (void*) swift_model_main_eval_pthread, (void*) &args[i]);
        if (rc){
            fprintf(stderr, "ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    swift_model_main_eval(mx, dx->subsets[0], &seeds[0], loglik, outputFile);

    pthread_attr_destroy(&attr);
    for(i=0; i<nthreads-1; i++) {
        rc = pthread_join(threads[i], NULL);
        if (rc) {
            fprintf(stderr, "ERROR; return code from pthread_join() is %d\n", rc);
            exit(-1);
        }
        for(j=0;j<N_LOGLIKS;j++) {
            loglik[j] += retvals[N_LOGLIKS*i+j];
        }
    }

    #else
    // dont parallelize, compile for subsetting anyway, be slow
    double retvals[N_LOGLIKS];
    if(dx->Nsubsets > 1) fprintf(stderr, "\tNeither OpenMP nor POSIX are enabled! Subsets will be evaluated sequentially.\n\n!!!!SLOW!!!!\n");
    for(i=0;i<dx->Nsubsets;i++) {
        swift_model_main_eval(mx, dx->subsets[i], NULL, retvals, outputFile);
        for(j=0;j<N_LOGLIKS;j++) {
            loglik[j] += retvals[j];
        }
    }

    #endif
    #endif

}

#endif


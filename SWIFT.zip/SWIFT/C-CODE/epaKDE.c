/*
 (Version 1.1, 29-SEP-2017)
 */

#define sq(A) ((A)*(A))

double epaKDE(double *d,int N,double val) {
	double sum, sqs, sd, bandwidth, P, dist, mindist;
	int i;

	sum = d[1];
	sqs = sq(d[1]);
	mindist = fabs(val - d[1]);
	for ( i=2; i<=N; i++ )  { 
	        sum += d[i];
	        sqs += sq(d[i]);
	        dist = fabs(val - d[i]);
	        mindist = mindist < dist ? mindist : dist;
	}
	sd = sqrt((sqs-sq(sum)/(1.0*N))/(1.0*N - 1.0));

	/* Scott's rule */ 
	bandwidth = 3.49*sd/pow(N,1.0/3.0);

	/* quick & dirty adjustment to cope with regions of 0-probability  */
	bandwidth =  mindist > bandwidth ? (mindist*1.1) : bandwidth;

	// calculate probability for val
	P = 0.0;
	for ( i=1; i<=N; i++ ) {
		// only include durations that won't evaluate to 0
		if (d[i]>(val-bandwidth) && d[i]<(val+bandwidth)) { 
			P += (3.0/4.0)*(1.0-sq((val-d[i])/bandwidth));
		}
	}
	P = P/((double) N * bandwidth);
	return P;
}
#undef sq

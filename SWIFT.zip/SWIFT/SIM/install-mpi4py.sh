#!/bin/sh


MPI4PYVER=3.0.0

module unload gcc
module load gcc/7.3.0
module unload mpi
module load mpi/mpi/mpich-3.2-x86_64

module list

cd ~

if [ ! -f mpi4py-${MPI4PYVER}.tar.gz ]
then
wget --no-proxy https://bitbucket.org/mpi4py/mpi4py/downloads/mpi4py-${MPI4PYVER}.tar.gz
fi

if [ -d mpi4py-${MPI4PYVER} ]
then
rm -R mpi4py-${MPI4PYVER}
fi

tar -zxf mpi4py-${MPI4PYVER}.tar.gz

cd mpi4py-${MPI4PYVER}

echo "[mpiorson2]
mpi_dir              = /usr/lib64/mpich-3.2
mpicc                = %(mpi_dir)s/bin/mpicc
mpicxx               = %(mpi_dir)s/bin/mpicxx
include_dirs         = /usr/include/mpich-3.2-x86_64
libraries            = mpich opa mpl
library_dirs         = %(mpi_dir)s/lib
runtime_library_dirs = %(library_dirs)s
" >> mpi.cfg

python setup.py build --mpi=mpiorson2

python setup.py install --user

rm -R mpi4py-${MPI4PYVER}


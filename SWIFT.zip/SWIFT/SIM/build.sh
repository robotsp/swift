#!/bin/sh

OUTFILE=./swiftstat

if [[ $(hostname -f) == *.hlrn.de && $(uname -s) == Linux ]]
then

echo "Building for MPP..."
module unload cray-mpich
module load cray-mpich/7.4.2
module load anaconda2
module list
cc --version
cc -o $OUTFILE-mpp ../C-CODE/swiftstat_mpi.c -lm
cc -homp -o ${OUTFILE} ../C-CODE/swiftstat_cli.c -lm
cc -homp -o ${OUTFILE}p ../C-CODE/swiftstat_clip.c -lm
module swap PrgEnv-cray PrgEnv-gnu
cd ../C-CODE
python setup.py build install --user --force clean --build-temp --build-lib
echo "Building for SMP..."
module unload sw.mpp1
module unload PrgEnv-cray
module load PrgEnv-gnu
module load sw.smp1
module unload gcc
module load gcc/4.8.2.hlrn
module unload cray-mpich
module load impi/2017.0.098
module list
mpicc -cc=gcc --version
mpicc -cc=gcc -O2 -fopenmp -o $OUTFILE-smp ../C-CODE/swiftstat_mpi.c -lm



elif [[ $(hostname -f) == head02 && $(uname -s) == Linux ]]
then

module unload gcc
module load gcc/7.3.0
module unload mpi
module load mpi/mpich-3.2-x86_64
module list
mpirun --version
gcc --version
cd ../C-CODE
gcc -O2 -o ../SIM/${OUTFILE} ../C-CODE/swiftstat_cli.c -DDISABLE_THREADS -lm &
gcc -O2 -fopenmp -o ../SIM/${OUTFILE}p ../C-CODE/swiftstat_cli.c -lm &
mpicc -cc=gcc -O2 -fopenmp -o ../SIM/$OUTFILE-mpi ../C-CODE/swiftstat_mpi.c -lm &
gcc -O2 -o ../SIM/seq2fixseqin ../C-CODE/swiftstat_seq2fixseqin.c -lm &
~/anaconda2/bin/python setup.py build install --install-lib=../MCMC clean --all & wait

elif [[ $(uname -s) == Darwin ]]
then

export CC=gcc-8
cd ../C-CODE
$CC -O2 -o ../SIM/${OUTFILE} ../C-CODE/swiftstat_cli.c -DDISABLE_THREADS -lm &
$CC -O2 -fopenmp -o ../SIM/${OUTFILE}p ../C-CODE/swiftstat_cli.c -lm &
$CC -O2 -fopenmp -o ../SIM/$OUTFILE-mpi ../C-CODE/swiftstat_mpi.c -lm $(mpicc --showme:compile) $(mpicc --showme:link) &
$CC -O2 -o ../SIM/seq2fixseqin ../C-CODE/swiftstat_seq2fixseqin.c -lm &
python2 setup.py build install --install-lib=../MCMC clean --all & wait

else
echo There is no build script for $(uname -s) on $(hostname -f).
exit 1
fi


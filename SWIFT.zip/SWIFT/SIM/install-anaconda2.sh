#!/bin/sh

wget --no-proxy -N https://repo.anaconda.com/archive/Anaconda2-5.1.0-Linux-x86_64.sh -O setup-anaconda2.sh

chmod +x setup-anaconda2.sh

./setup-anaconda2.sh

rm setup-anaconda2.sh


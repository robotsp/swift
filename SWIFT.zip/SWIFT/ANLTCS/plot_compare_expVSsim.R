# plot comparison between experimental and simulated data
  source("s_settings.R")
  library(data.table)
  library(ggplot2)
  library(scales)
  load(file.path(base_directory,"RData/emp_estimation/auxiliary_vars.Rdata")) # for MEPs, priors and friends
  rm(seq)
  load(file.path(base_directory,"RData/emp_estimation/fixation_sequences.Rdata")) # simulated and experimental fixation sequences
  load(file.path(base_directory,"RData/sim_estimation/fixation_sequences.Rdata")) # simulated and experimental fixation sequences
  seq <- rbind(seq_emp,seq_sim)
  # plot ----
  
  ###### fixation duration means
  # calculate them
  if (exists("durs")) rm(durs)
  tmp <- seq[fp == 1 & fl == 0, .(m = mean(dur)), by="src,PP"]
  tmp$durtype = "all"
  durs <- tmp
  
  tmp <- seq[fl == 0 & xnfix1 == 1, .(m = mean(dur)), by="src,PP"]
  tmp$durtype = "ffd"
  durs <- rbind(durs,tmp)
  
  tmp <- seq[fl == 0 & xnfix1 == 1 & cnfix1 == 1, .(m = mean(dur)), by="src,PP"]
  tmp$durtype = "sfd"
  durs <- rbind(durs,tmp)
  
  tmp <- seq[fl == 0 & xnfix1 == 2 & cnfix1 > 1, .(m = mean(dur)), by="src,PP"]
  tmp$durtype = "rfx"
  durs <- rbind(durs,tmp)
  
  tmp <- seq[fp == 1, .(s = sum(dur)*as.numeric(all(fl==0))), by="src,PP,run,sn,wn"]
  tmp <- tmp[s != 0, .(m=mean(s)), by="PP,src"]
  tmp$durtype = "gd"
  durs <- rbind(durs,tmp)
  
  tmp <- seq[, .(s = sum(dur)*as.numeric(all(fl==0))), by="src,PP,run,sn,wn"]
  tmp <- tmp[s != 0, .(m=mean(s)), by="PP,src"]
  tmp$durtype = "tvt"
  durs <- rbind(durs,tmp)
  
  # cast (and reorder?)
  cdurs <- dcast(durs,PP+durtype~src,value.var="m")
  cdurs$durtype <- factor(cdurs$durtype, levels=c("all", "sfd", "ffd", "rfx", "gd", "tvt"))
  cdurs[, ':='(exp=exp/1000, 
               sim = sim/1000)]
  
  szf <- 0.1
  
  # plot fixation duration comparison ----
  p1 <-
    ggplot(cdurs[durtype %in% c("ffd", "sfd", "rfx", "gd", "tvt")], aes(exp,sim, color=as.factor(durtype), fill=as.factor(durtype))) + 
    geom_abline(size=1*szf) + 
    stat_ellipse(type = "t",linetype=2,geom="polygon",alpha = .01, size=5*szf) +
    geom_point(size=1.3*szf) + 
    scale_x_continuous("Experimental fixation durations [s]") + 
    scale_y_continuous("Simulated ixation durations [s]", position = "left")+
    scale_color_discrete(name = element_blank(),
                         labels = c("FFD", "SFD", "RFD", "GD", "TVT")) +
    scale_fill_discrete(guide = F) +
    scale_linetype(guide=F) +
    coord_equal(xlim=c(120,450)/1000,ylim=c(120,450)/1000,expand = c(0,0)) +
    theme_bw() +
    theme(text = element_text(size=label_size),
          strip.background = element_blank(),
          strip.text = element_text(size=facet_size),
          panel.grid.minor = element_blank(),
          plot.title = element_text(size = label_size),
          axis.text = element_text(size = tick_label_size),
          legend.position = c(.88,.31),
          legend.background = element_blank(),
          legend.key = element_blank(),
          aspect.ratio = 1)
  
  ggsave(file="fig_fdurcomp.pdf",
         path = file.path(base_directory,"PLOTS"),
         device="pdf", width=7,height=7,units="cm", plot=p1)
  
  
  
  # plot fixation probabilities comparison ----
  # for WORDBASED analysis first load corpus
  rm("wbprob")
  load(file.path(base_directory,"RData/emp_estimation/wbprobs.Rdata"))
  load(file.path(base_directory,"RData/sim_estimation/wbprobs.Rdata"))
  wbprob <- rbind(wbprob_emp,wbprob_sim)
  
  mprobs <- melt(data = wbprob, id.vars = c("PP","src"),measure.vars = c("skip", "sf", "rfx", "rgo"), variable.name = "type", value.name = "P")
  cprobs <- dcast(mprobs,PP+type~src,value.var="P")
  # cast (and reorder?)
  cprobs$type <- factor(cprobs$type, levels=c("sf", "rfx", "rgo", "skip"))
  
  p2 <-
    ggplot(cprobs, aes(exp,sim, color=as.factor(type), fill = as.factor(type))) +
    geom_abline(size=1*szf) + 
    # geom_abline(intercept = 0, slope = tan(pi/2), color = "black", size = .4) + 
    # geom_abline(intercept = 0, slope = 0, color = "black", size = .4) + 
    stat_ellipse(type = "norm", linetype=2, geom="polygon", alpha = .01, size=5*szf) +
    geom_point(size=1.3*szf) + 
    scale_x_continuous("Experimental fixation probabilities",
                       # labels = percent,
                       breaks = c(0,.5,1)) + 
    scale_y_continuous("Simulated fixation probabilities ",
                       # labels = percent,
                       # position="right",
                       breaks = c(0,.5,1)) +
    scale_color_discrete(name = element_blank(),
                         labels = c("SF", "RF", "RG", "SK")) +
    scale_fill_discrete(guide = F) +
    scale_linetype(guide=F) +
    coord_equal(xlim=c(0,1.0035),ylim=c(0,1.0035), expand = c(0,0)) +
    theme_bw() +
    theme(text = element_text(size=label_size),
          strip.background = element_blank(),
          strip.text = element_text(size=facet_size),
          panel.grid.minor = element_blank(),
          plot.title = element_text(size = label_size),
          axis.text = element_text(size = tick_label_size),
          legend.position = c(.88,.28),
          legend.background = element_blank(),
          legend.key = element_blank(),
          aspect.ratio = 1)
  ggsave(file = "fig_fprobcomp.pdf",
         path = file.path(base_directory, "PLOTS"), 
         device="pdf", width=7,height=7,units="cm", plot=p2)
  

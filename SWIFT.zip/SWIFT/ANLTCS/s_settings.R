rm(list=ls())
library(pbmcapply)
library(parallel)
library(scales)
library(data.table)
library(ggplot2)

base_directory <- "~/Documents/Lehre/Reproducibility/new_OSF/SWIFT/"
# base_directory <- "~/SWIFT"  # change this to the directory of SWIFT
plot_directory <- "FIGURES"
sim_directory <- "SIM" # path to simulation directory
data_directory <- "DATA" # path to data directory
chains_dir <- "MCMC" # path to MCMC chains

corpus_identifier <- "PB2"
fixseq_identifier <- "PB2expVP"


# some functions and variables used for plotting
# labeller function
label_parameters <- as_labeller(c('msac' = "paste('Saccadic timer ', italic(t[sac]))", 
                                  'refix' = "paste('Refixation factor ', italic(R[]))", 
                                  'delta0' = "paste('Processing span ', italic(delta[0]))", 
                                  'eta' = "paste('Word length exponent ', italic(eta))"))

Subject <- 15 # dataset (participant) to print (set = 0 for all participants)
label_size = 8
facet_size = 10
tick_label_size = 8
szf = .1 # size factor for all size-properties of plot-graphics (not text)

Ncores <- detectCores()
intBreaks <- function(x, n = 5) pretty(x,n)[pretty(x,n) %% 1 == 0]
dblBreaks <- function(x, n = 5) sprintf("%.1f", x)
"%ni%" <- Negate("%in%") # opposite of %in%

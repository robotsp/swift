#### relationship of recovered MAPs with true values ----
source("s_settings.R")


load(file.path(base_directory,"RData/emp_estimation/postPE.Rdata"))
truepars <- postPE[, .(emp_pMAP = pooled_MAP), by="dset,parname"]
setkey(truepars, dset, parname) 

load(file.path(base_directory,"RData/sim_estimation/postPE.Rdata"))
setkey(postPE, dset, parname) 
postPE <- postPE[, postPE[, .(sim_pMAP = pooled_MAP), by="dset,parname"]]
postPE <- postPE[truepars]

# load priors
load(file.path(base_directory, "RData/emp_estimation/auxiliary_vars.Rdata"))

# point out some arbitrary participants ----
ix <- which(postPE[parname == "msac"]$emp_pMAP%in%sort(postPE[parname == "msac"]$emp_pMAP)[c(4,13,25,32)])
colour_these <- c(postPE[parname == "msac"]$dset[ix])



szf <- 1

# labeller function 2
label_parameters2 <- as_labeller(c('msac' = "paste('Saccadic timer ', italic(t[sac]), ' (empirical)')", 
                                   'refix' = "paste('Refixation factor ', italic(R[]), ' (empirical)')", 
                                   'delta0' = "paste('Processing span ', italic(delta[0]), ' (empirical)')", 
                                   'eta' = "paste('Word length exponent ', italic(eta), ' (empirical)')"))

for (par in unique(postPE$parname)) {
  p1 <-
    ggplot(postPE[parname == par & dset %ni% colour_these], aes(emp_pMAP, sim_pMAP)) + 
    geom_abline(slope = 1, size = .5) + 
    geom_point(size = 1*szf) + 
    geom_point(data = postPE[parname == par & dset %in% colour_these], aes(emp_pMAP, sim_pMAP, color = as.factor(dset)), size = 2*szf, alpha = .99, shape = 16) + 
    theme_bw() + 
    theme(text = element_text(size=label_size),
          strip.background = element_blank(),
          strip.text = element_text(face="bold",
                                    size=facet_size),
          panel.grid.minor = element_blank(), 
          axis.text = element_text(size = tick_label_size)) +
    # scale_colour_viridis(guide = F, discrete = T) + 
    scale_color_discrete(guide = F) + 
    scale_y_continuous(breaks = pretty_breaks(n = 3),
                       name = "Recovered MAP estimator",
                       expand = c(0,0),
                       limits = as.numeric(priors[parname == par, .(lb,ub)])) + 
    scale_x_continuous(name = parse(text = label_parameters2(par)),
                       limits = as.numeric(priors[parname == par, .(lb,ub)]),
                       breaks = pretty_breaks(n = 4), 
                       expand = c(0,0)) +
    theme(aspect.ratio = 1)
  
  p1
  

  ggsave(p1, 
         path = file.path(base_directory,"PLOTS"), 
         filename = paste0("fig_relation_true_v_recovered_pars",par,".pdf"), device = "pdf", units = "cm", width = 7, height = 7)
}


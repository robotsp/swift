# load empirical and simulated data from data directory
# collect and enrich empirical and simulated input-style data
  source("s_settings.R")
  library(data.table)
  "%ni%" <- Negate("%in%") # opposite of %in%
  load(file.path(base_directory,"RDATA/emp_estimation/postPE.Rdata")) # only to get PP numbers
  
  
  oldwd <- getwd()
  setwd(file.path(base_directory,"DATA"))
  d <- dir(pattern="fixseqin_.*\\.dat")
  # load data ----
  seq <- data.table()
  for (pp in unique(postPE$dset)) {
    # load empirical data
    fname <- file.path(base_directory, "DATA", paste0("fixseqin_",fixseq_identifier,pp,".dat"))
    tmp <- as.data.table(read.table(file = fname))
    tmp$PP <- pp
    tmp$src <- "exp"
    tmp$run <- 1
    seq <- rbind(seq,tmp)
    # load simulated data
    fname <- file.path(base_directory,"DATA", paste0("fixseqin_",fixseq_identifier,pp,"_model.dat"))
    print(paste0("loading ",fname))
    tmp <- as.data.table(read.table(file = fname))
    tmp$PP <- pp
    tmp$src <- "sim"
    # mark multiple runs as such
    tmp[,run:=cumsum(V6 == 1), by="V1"]
    seq <- rbind(seq,tmp)
  }
  setnames(seq,1:9,c("sn", "wn", "let", "dur", "sdur", "fl", "V1", "V2", "fixnum")) # name columns 
  
  # drop unnecessary columns
  seq$V1 <- NULL
  seq$V2 <- NULL
  seq$V10 <- NULL
  
  # load corpus ----
  Rcorpus <- paste0("Rcorpus_", corpus_identifier, ".dat")
  words <- as.data.table(read.table(file = file.path(base_directory,"DATA",Rcorpus), header = F, sep = "\t", dec = ".")) # W??rter einlesen
  setnames(words, c("SN", "NW", "WN",  "L", "FREQ", "TWX"))
  
  # annotate sequences ----
  # number of words per sentence
  seq[, nw:=words[SN==sn]$NW[1], by="sn"]
  # add frequency and word length information
  seq[, ':='(freq = words[SN == sn & WN == wn]$FREQ,
             wlen = words[SN == sn & WN == wn]$L), by="sn,wn"]
  
  # word boundaries
  words[, ':='(w_on = cumsum(L)-L+WN-1) , by="SN"]
  words[WN == 1]$w_on <- 1
  seq[, w_on := words[WN == wn & SN == sn]$w_on, by="sn,wn"]
  
  # determine saccade lengths, first/second pass fixations etc.  
  # incoming/outgoing saccade type
  seq[, ':='(styp_in = c(NA,diff(wn)) ), by="src,PP,run,sn"]
  seq[, ':='(styp_out = c(diff(wn),NA) ), by="src,PP,run,sn"]
  
  ## saccade length
  seq[, slen_in := c(NA, (w_on[2:.N] + let[2:.N]) - (w_on[1:(.N-1)] + let[1:(.N-1)]) ), by="src,PP,run,sn"]
  seq[, slen_out := c((w_on[2:.N] + let[2:.N]) - (w_on[1:(.N-1)] + let[1:(.N-1)]),NA), by="src,PP,run,sn"]
  
  # mark first pass fixations
  seq[, ':='(maxwn = cummax(wn)), by="src,PP,run,sn"] # maximum wordnumber fixated so far
  seq[, ':='( fp = ifelse(c(1,diff(fixnum)) == 1 & wn == maxwn, 1, 2)  ), by="src,PP,run,sn,wn"]
  seq[, ':='(fp = cummax(fp)), by="src,PP,run,sn,wn"] # get second pass refixations
  
  # enumerate fixations per pass
  seq[, ':='(xnfix1 = c(1:.N) * as.numeric(fp == 1),
             xnfix2 = c(1:.N) * as.numeric(fp == 2)), by="src,PP,run,sn,wn,fp"]
  
  # count fixations per pass
  seq[, ':='(cnfix1 = sum(fp == 1),
             cnfix2 = sum(fp == 2)), by="src,PP,run,sn,wn"]
  
  # fixation onset time abs
  seq[, fixon := c(0,cumsum(dur[1:(.N-1)]) + cumsum(sdur[1:(.N-1)])), by="src,PP,run,sn"]
  
  # save seqs separately in respective directories
  seq_emp <- seq[src == "exp"]
  save(file = file.path(base_directory,"RDATA/emp_estimation/fixation_sequences.Rdata"), list = "seq_emp")
  seq_sim <- seq[src == "sim"]
  save(file = file.path(base_directory,"RDATA/sim_estimation/fixation_sequences.Rdata"), list = "seq_sim")
  
  
  
  # calculate word based fixation probabilities ----
  # first, create a word based table per participant ( & run for simulated data with multiple readings)
  newDT <- data.table()
  PPsnRuns <- unique(seq[,.(src,PP,run)])
  for (thisrun in 1:nrow(PPsnRuns)) {
    # add ID-columns
    tmp <- words[, ':='(run = PPsnRuns[thisrun]$run,
                        PP = PPsnRuns[thisrun]$PP,
                        src = PPsnRuns[thisrun]$src)]
    # restrict to included sentences
    sn_included <- unique(seq[run == PPsnRuns[thisrun]$run & 
                                PP == PPsnRuns[thisrun]$PP &
                                src == PPsnRuns[thisrun]$src,]$sn)
    newDT <- rbind(newDT,tmp[SN %in% sn_included,])
  }
  setnames(newDT, 1:6,c("sn","nw","wn","wlen","freq","twx"))
  newDT$twx <- NULL
  setkey(newDT, run,PP,src,sn,wn,wlen,freq,nw,w_on)
  wbseq <- merge(newDT,seq, all = T)
  wbseq[, ':='(highest_fix = max(wn[!is.na(fixnum)]),
               lowest_fp = wn[which(fl == 1)]), by="src,PP,run,sn"]
  
  wbseq[is.na(fl)]$fl <- 0
  
  # skippings are defined as words with NO first pass fixations, which have been skipped over (i.e. not words with wn <= first fixated word); rest must be NA; if last fixated word is not the highest word it must be included (as F)
  # refixation probabilitiy is 1-single fixation probability
  fpskp <- wbseq[wn > lowest_fp & wn <= highest_fix & wn != nw, .(skipfp = any(is.na(fixnum) | (cnfix1 == 0 & cnfix2 != 0))), by="src,PP,run,sn,wn"]
  
  # single fixations are defined as words which have been fixated in first pass ONCE; words skipped in FP and first fixation in sentence are NA
  fpsf  <- wbseq[wn > lowest_fp & fl < 2, .(sf = as.logical(sum(ifelse(cnfix1 != 0, any(cnfix1 == 1),NA)))), by="src,PP,run,sn,wn"]
  
  # regression probabilities are calculated from regressions out of first-pass fixation on words
  fprg  <- wbseq[fl != 1 & wn > 1 & wn <= highest_fix, .(rgo = ifelse(xnfix1 != 0, any(styp_out < 0),NA)), by="src,PP,run,sn,wn"]
  fprg  <- fprg[, .(rgo = ifelse(all(is.na(rgo)), NA, as.logical(sum(rgo, na.rm=T)))), by="src,PP,run,sn,wn"]
  
  tmp <- merge(fpskp,fpsf,all=T)
  wblog <- merge(tmp,fprg,all=T)
  wbprob <- wblog[, .(skip = mean(skipfp, na.rm=T),
                      sf = mean(sf, na.rm=T),
                      rgo = mean(rgo,na.rm=T)), by="src,PP"]
  wbprob[, rfx:=1-sf]
  
  # save probabilities
  wbprob_emp <- wbprob[src == "exp"]
  save(file = file.path(base_directory,"RDATA/emp_estimation/wbprobs.Rdata"), list = "wbprob_emp")
  
  wbprob_sim <- wbprob[src == "sim"]
  save(file = file.path(base_directory,"RDATA/sim_estimation/wbprobs.Rdata"), list = "wbprob_sim")
  
  setwd(oldwd)
  

# compare eye movement data (Figures 8 and 9) ----
  source("plot_compare_expVSsim.R")
# plot 1d likelihood function for some parameters
source("s_settings.R")
library(data.table)
library(parallel)
library(ggplot2)
library(pbmcapply) 


generate_data = T # generate data or use pre-existing dataset?
progress_bar = T # progress bar requires package "pbmcapply"
plot_LLcontributions = T # plot temporal and spatial likelihood

# specify algorithm ----
default_parfile <- "DATA/swpar_PB2_PB2expVP1.par" # parfile to be used if generate_data = T, ignored otherwise
fixseq <- "recovery1" # ignored if generate_data = T
N_sims <- 1
N_liks <- 1
N_grid <- 1000

#                parname,     lb,     ub,     true
parms <- list(c("delta0",          4,       15,       8.5),
              c("msac"  ,        1.5,      3.5,       2.6),
              c("refix" ,        0.2,      1.8,       0.9),
              c("eta",           0.01,      1.0,       0.4))
              
# function: evaluate 1 likelihood
evalpar <- function(job) {
  # job must at least contain parname, parva, corpus-id  and fixseq-id
  job <- as.data.table(job)
  
  command <- paste0(file.path(base_directory,sim_directory),"/swiftstat -c ", job$corpus_identifier, " -s ",job$fixseq," -f -P ", job$parname, "=", sprintf("%.4f",job$parval))

  start_time <- Sys.time()
  tmp <- system(command, intern = T)
  tmp <- as.numeric(unlist(strsplit(gsub(".*loglik: (.*)","\\1",tmp[length(tmp)]),", ")))
  dt.out <- as.data.table(c(job, 
                            dur = (Sys.time()-start_time)[[1]], 
                            LL = tmp[1],
                            LLtemp = tmp[2],
                            LLspat = tmp[3]))
                       
  return(dt.out)
}


# copy & adjust parameter file ----
if (generate_data == T) {
  fixseq <- "1dliketest"
  f_defparf <- file.path(base_directory, default_parfile)
  f_newparf <- file.path(base_directory,data_directory,paste0("swpar_",corpus_identifier,"_1dliketest.par"))
  if (!file.copy(from = f_defparf, to = f_newparf, overwrite = T)) stop("parameter file could not be copied")
  for (p in parms) {
    command <- paste0("sed -Ei '' 's/^(",p[1],"[[:space:]]+).*/\\1",sprintf("%.4f",as.double(p[4])),"/' ", f_newparf)
    print(command)
    system(command)
  }
}

# generate data ----
oldwd <- getwd()
setwd(file.path(base_directory,sim_directory))
# compile swift
system("./build.sh", intern = T) 
# change config-file
f_conf <- file.path(base_directory,data_directory,"swiftstat.inp")
sinp <- read.table(f_conf)
if (generate_data == T) {
  sinp[which(sinp$V1 == "runs"),]$V2 <- N_sims
  write.table(file = f_conf, x = sinp, quote = F,row.names = F, col.names = F)
  # start simulation
  command_swift <- paste("./swiftstat -c ", corpus_identifier, " -s 1dliketest -gx") 
  system(command_swift)
  # rename and move output-file
  file.rename(from = paste0("fixseqin_1dliketest.dat"), to = paste0("../DATA/fixseqin_1dliketest.dat"))
}
# change config-file to runs = 1
sinp[which(sinp$V1 == "runs"),]$V2 <- 1
write.table(file = f_conf, x = sinp, quote = F,row.names = F, col.names = F)
setwd(oldwd)

# grid based likelihood evaluation (parallel) ----
jobs <- unlist(
  lapply(parms, function(parm) unlist(
    lapply(as.list(seq(parm[2],parm[3],length.out = N_grid)), function(val)
      lapply(as.list(1:N_liks), function(N)
        list(parname = parm[1],
             parval = val,
             n = N,
             corpus_identifier = corpus_identifier,
             fixseq = fixseq))),recursive = F)),recursive=F)



# execute in parallel
N_cores <- detectCores()
oldwd <- getwd()
setwd(file.path(base_directory,sim_directory))
if (progress_bar) {
  dt_list <- pbmclapply(X = jobs, FUN = evalpar, mc.cores = N_cores)
} else {
  dt_list <- mclapply(X = jobs, FUN = evalpar, mc.cores = N_cores)
}
setwd(oldwd)
LLdt <- do.call("rbind",dt_list)

# collect original parameters in data.table
truepars <- do.call("rbind",lapply(parms, function(x) data.table(parname = x[1],
                                                                 trueval = as.numeric(x[4]))))

# plot ----
tmp <- LLdt[, .(rh = max(LL), rl = min(LL)), by="parname"]
ylims <- c(max(tmp$rl),max(tmp$rh))

plotname <- paste0(N_liks*N_grid, " LLs of ", N_sims, " runs")

f_data <- file.path(base_directory, "RDATA", paste0("1dlik_", paste0(unique(LLdt$parname), collapse="_"), "_", format(Sys.time(), "%b%d_%X"), ".Rdata"))
save(file = f_data, 
     list = c("LLdt", "truepars"))


# plot results
tmp <- LLdt
tmp[, ':='(LL = LL-mean(LL),
           LLtemp = LLtemp-mean(LLtemp),
           LLspat = LLspat-mean(LLspat)), by="parname"]
tmp2 <- melt(tmp, id.vars = c("parname", "parval"), 
             measure.vars = c("LL", "LLtemp", "LLspat"), 
             variable.name = "LLtype", 
             value.name = "val")

tmp2$LLtype <- factor(tmp2$LLtype, 
                      levels = c("LLtemp", 
                                 "LLspat", 
                                 "LL"), 
                      labels = c("Temporal contribution", 
                                 "Spatial contribution", 
                                 "Sum"))


gglegend <- function(x){ 
  tmp <- ggplot_gtable(ggplot_build(x)) 
  leg <- which(sapply(tmp$grobs, function(y) y$name) == "guide-box") 
  tmp$grobs[[leg]]
}

for (par in unique(truepars$parname)) {
  p1 <- ggplot(tmp2[parname == par], aes(x = parval, y = val, color = LLtype)) + 
    geom_point(size=0.3, alpha = 0.8, stroke = 0) +
    geom_vline(data = truepars[parname == par], aes(xintercept = trueval)) + 
    theme_bw() + 
    theme(text = element_text(size=label_size),
          strip.background = element_blank(),
          strip.text = element_text(face="bold",
                                    size=facet_size), 
          panel.grid.minor = element_blank(), 
          axis.text = element_text(size = tick_label_size),
          aspect.ratio = 1) +
    scale_color_manual(values = c("red", "blue", "black"), 
                       name = "", 
                       guide = F) + 
    scale_y_continuous(breaks = pretty_breaks(n = 3),
                       name = "Centered log-likelihood",
                       expand = c(0,0)) +
                       # limits = c(-150,150)) + 
    scale_x_continuous(name = parse(text = label_parameters(par)),
                       breaks = pretty_breaks(n = 4), 
                       expand = c(0,0))
  # guides(colour = guide_legend(override.aes = list(size = 1, alpha = 1)))
  
  ggsave(p1, filename = file.path(base_directory, "FIGURES", paste0("Fig5_",par,".pdf")), device = "pdf", units = "cm", width = 7, height = 7)
}

ggsave(gglegend(p1 + guides(colour = guide_legend(override.aes = list(size = 2, 
                                                                      alpha = 1))) +
                  theme(legend.direction = "horizontal")), 
       filename = file.path(base_directory, "FIGURES", paste0("Fig5_legend.pdf")), device = "pdf", units = "cm", width = 7, height = 7)



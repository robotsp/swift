source("s_settings.R")
library(data.table)
library(ggplot2)

load(file.path(base_directory, "RData/emp_estimation/chainsls.Rdata")) # load chains (long) without burn in
load(file.path(base_directory, "RData/emp_estimation/postPE.Rdata")) # load point estimates
load(file.path(base_directory, "RData/emp_estimation/auxiliary_vars.Rdata")) # load priors

dir.create(file.path(base_directory,"PLOTS")) # make sure the plot directory is there
szf <- .8
if (Subject == 0) Subject <- seq(1,34)

# make priors plottable
# give eta a nudge
priors[parname == "eta", lb:=0]
# melt priors to adjust scale
plot_priors <- melt(priors, id.vars = "parname", measure.vars = c("lb", "ub"), value.name = "val", variable.name = "bound_type")

# create prior line
N <- 100
normfac <- 1/(pnorm(.5)-pnorm(-.5))
prior_d <- priors[, .(x = seq(lb,ub,length.out = N),
                      d = dnorm(mean = (ub-lb)/2+lb,
                                sd = ub-lb,
                                x = seq(lb,ub,length.out = N))*normfac), by="parname"]
prior_d$dset <- NA


# posterior chains per participant (Fig. 7)
for (s in Subject) {
  for (par in unique(chainsls$par)) {
    p1 <- ggplot(chainsls[dset == s & parname == par], aes(val, color = as.factor(chain))) +
      stat_density(geom="line", position="identity", size=.5*szf) + 
      geom_line(data = prior_d[parname == par], aes(x,d), color = "black", size = .4*szf, linetype = "dotted") + 
      geom_vline(data = postPE[dset == s & parname == par], aes(xintercept = pooled_MAP), size = .5*szf) +
      stat_density(geom="line", position="identity", aes(val), color="black",size=0.5*szf) + 
      # facet_wrap(~parname, 
      #            scales="free",
      #            labeller = label_parameters) + 
      theme_bw() + 
      theme(text = element_text(size=label_size),
            strip.background = element_blank(),
            strip.text = element_text(face="bold",
                                      size=facet_size),
            # panel.grid = element_blank(), 
            panel.grid.minor = element_blank(),
            axis.text = element_text(size = tick_label_size)) +
      scale_color_discrete(guide=F) + 
      scale_y_continuous(breaks = pretty_breaks(n = 4),
                         labels = dblBreaks,
                         name = element_blank()) + 
      scale_x_continuous(name = parse(text = label_parameters(par)),
                         limits = as.numeric(priors[parname == par, .(lb,ub)]),
                         breaks = pretty_breaks(n = 4), 
                         expand = c(0,0)) +
      theme(aspect.ratio = 1)
    
    ggsave(p1, 
           path = file.path(base_directory,"PLOTS"),
           filename = paste0("fig_singlePP", s, "_allchains_",par,".pdf"), 
           device = "pdf", units = "cm", width = 7, height = 7)}
}



# pooled posteriors of all PPs (Fig. 8)

ix <- which(postPE[parname == "msac"]$pooled_MAP%in%sort(postPE[parname == "msac"]$pooled_MAP)[c(4,13,25,32)])
colour_these <- c(postPE[parname == "msac"]$dset[ix])

szf <- 1
for (par in unique(chainsls$par)) {
  p1 <- ggplot(chainsls[parname == par], aes(val, group = as.factor(dset))) + 
    stat_density(geom="line", position="identity", size=.3*szf, color = "gray60") + 
    geom_point(data = postPE[parname == par], aes(x = pooled_MAP, y = 0), size = 3*szf, shape = 124, color = "gray50") +
    geom_line(data = prior_d[parname == par], aes(x,d), color = "black", size = .4*szf, linetype = "dotted") + 
    stat_density(data = chainsls[parname == par & dset %in% colour_these], aes(val, colour = as.factor(dset)), geom="line", position="identity", size=.6*szf) + 
    geom_point(data = postPE[parname == par & dset %in% colour_these], aes(x = pooled_MAP, y = 0, colour = as.factor(dset)), size = 3*szf, shape = 124) +
    theme_bw() + 
    theme(text = element_text(size=label_size),
          strip.background = element_blank(),
          strip.text = element_text(face="bold",
                                    size=facet_size),
          panel.grid.minor = element_blank(), 
          axis.text = element_text(size = tick_label_size)) +
    scale_color_discrete(guide=F) + 
    scale_y_continuous(breaks = pretty_breaks(n = 4),
                       labels = dblBreaks,
                       name = element_blank()) + 
    scale_x_continuous(name = parse(text = label_parameters(par)),
                       limits = as.numeric(priors[parname == par, .(lb,ub)]),
                       breaks = pretty_breaks(n = 4), 
                       expand = c(0,0)) +
    theme(aspect.ratio = 1)
  p1  
  
  ggsave(p1, 
         path = file.path(base_directory,"PLOTS"),
         filename = paste0("fig_allPP_pooledchains_",par,".pdf"), 
         device = "pdf", units = "cm", width = 7, height = 7)
}

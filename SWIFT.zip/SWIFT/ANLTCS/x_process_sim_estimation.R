# process results of parameter estimation on experimental data
source("s_settings.R")
save_dir <- "estimation_sim"
chain_id <- "PP"
burn_in <- 0.5 # initial proportion of iterations counted as burn in

# process results of parameter estimation for experimental data 
oldwd <- getwd()
setwd(file.path(base_directory,chains_dir))
if (file.exists(save_dir)) {
  warning("1.1: target directory already exists; no files moved") 
} else {
  d <- dir(pattern = paste0("^",chain_id,"[[:digit:]]+_[[:digit:]]+.*\\.(dat).*"))
  datasets <- unique(gsub(pattern = paste0("^",chain_id,"([[:digit:]]+)_.*"), replacement = "\\1",x = d))
  
  # move chain-files ----
  for (file in d) {
    system(paste0("mv -f ", file, " ", save_dir, "/" ))
  }
}
setwd(oldwd)



# calculate posterior point estimates for data simulation
library(data.table)
library(parallel)
library(pbmcapply)
library(coda)

oldwd <- getwd()
setwd(file.path(base_directory,chains_dir,save_dir))
if (file.exists(file.path(base_directory,"RDATA/sim_estimation/chainsls.Rdata"))) {
  warning("1.2: chains already aggregated in DATA subdirectory..")
} else {
  dir.create(file.path(base_directory,"RDATA/sim_estimation"), recursive = T) # make sure it's there
  # initialise 
  chainswf <- data.table()
  # iterate over PPs
  dfiles <- dir(pattern = paste0("dat$"))
  for (d in dfiles) {
    d_num <- as.numeric(gsub(paste0(".*",chain_id,"([[:digit:]]+)_[[:digit:]]+\\.dat"), "\\1",d))
    chain_num <- as.numeric(gsub(paste0(".*",chain_id,"[[:digit:]]+_([[:digit:]]+)\\.dat"), "\\1",d))
    a <- as.data.table(read.table(d, header=T,sep=","))
    print(paste("PP",d_num, "chain", chain_num))
    a$chain <- chain_num
    a$dset <- d_num
    a[,':='(n=1:.N),by="chain"] # explicit row numbers 
    # chains wide full (with burn in)
    chainswf <- rbind(chainswf,a)
  }
  # do some tests
  tmp <- chainswf[, .(.N), by="dset,chain"]
  if (length(unique(tmp$N)) != 1) stop("Chains are of unequal length!")
  if (length(unique(tmp[,.(.N), by="dset"]$N)) != 1) stop("Unequal number of chains per dataset!")
  
  chainswf[,":="(burn_in = n<=burn_in*.N), by="dset,chain"]
  
  # names of parameters  ----
  Npar <- sum(!(names(chainswf) %in% c("loglik", "chain", "dset", "n", "burn_in", "x_LL", "x_LL1", "x_LL2", "y_LL", "y_LL1", "y_LL2" )))
  parnames <- names(chainswf)[1:Npar]
  
  # get rid of burn in, as it blows up memory usage  ----
  chainsws <- chainswf[burn_in == F]
  rm(chainswf)
  
  # melt to long format ----
  chainsls <- melt(chainsws, 
                   measure.vars = 1:Npar,
                   variable.name = "parname", value.name = "val")
  
  # save chains
  save(file=file.path(base_directory,"RDATA/sim_estimation/chainsws_exp.Rdata"), "chainsws")
  save(file=file.path(base_directory,"RDATA/sim_estimation/chainsls_exp.Rdata"), "chainsls")
  
  gc(verbose = T) # free memory
  
  # read priors from text file ----
  priors <- as.data.table(read.table(file = file.path(base_directory,"MCMC/priors.par"), header = T, dec = "."))
  
  # further test
  if (!all(priors$parname %in% parnames)) stop("Parameter names from prior file don't match with parameter names from chains!")
  
  save(file=file.path(base_directory,"RDATA/sim_estimation/auxiliary_vars.Rdata"), list = c("Npar",
                                                                                            "parnames", 
                                                                                            "priors",
                                                                                            "burn_in"))
  # calculate point estimate(s) of posterior parameter distribution
  postPE <- unique(chainsls[, .(dset, parname)])
  setkey(postPE, dset, parname)
  
  # calculate mean of MAPs per chain ----
  MAPfun <- function(x) {
    d <- density(chainsls[dset == x$dset & parname == x$parname & chain == x$chain]$val)
    d <- d$x[which.max(d$y)]
    return(c(x, chainMAP = d))
  }
  
  tmp <- unique(chainsls[, .(parname,dset,chain)])
  tmp <- split(tmp,seq(nrow(tmp)))
  tmp2 <- pbmclapply(FUN = MAPfun, X = tmp, mc.cores = 8)
  tmp2 <- as.data.table(do.call(rbind.data.frame, tmp2))
  tmp3 <- tmp2[, .(mean_chainMAP = mean(chainMAP)), by="dset,parname"]
  setkey(tmp3, dset, parname)
  postPE <- postPE[tmp3]
  
  
  # calculate MAPs for pooled chains ----
  MAPfun <- function(x) {
    d <- density(chainsls[dset == x$dset & parname == x$parname]$val)
    d <- d$x[which.max(d$y)]
    return(c(x, pooled_MAP = d))
  }
  
  tmp <- unique(chainsls[, .(parname,dset)])
  tmp <- split(tmp,seq(nrow(tmp)))
  tmp2 <- mclapply(FUN = MAPfun, X = tmp, mc.cores = 36)
  tmp2 <- as.data.table(do.call(rbind.data.frame, tmp2))
  setkey(tmp2, dset, parname) 
  postPE <- postPE[tmp2]
  
  # save chains & point estimates -----
  save(file=file.path(base_directory,"RDATA/sim_estimation/postPE.Rdata"), "postPE")
}
setwd(oldwd)



# compare posterior point estimates for empirical and simulated data (Figure 9)
source("plot_compare_posteriors.R")

# simulate new data using point estimates from estimation of empirical data
source("s_settings.R")
oldwd <- getwd()


# load data ----
load(file.path(base_directory,"RDATA/emp_estimation/postPE.Rdata")) # load point estimators 

# simulate data

# make sure runs = 1
command = "sed -Ei '' 's/(^runs[[:space:]]+).*/\\11/' swiftstat.inp"
setwd(file.path(base_directory, "DATA"))
system(command)

setwd(file.path(base_directory, "SIM"))
for (i in unique(postPE$dset)) {
  parstr = ""
  for (j in unique(postPE[dset == i]$parname)) {
    parstr = paste0(parstr,j, "=", postPE[dset == i & parname == j]$pooled_MAP, ",")
  }
  parstr = substr(parstr,1,nchar(parstr)-1)
  command = paste0("./swiftstat -c ", corpus_identifier, " -s ", fixseq_identifier, i," -P ", parstr, " -gx")
  system(command)
  file.rename(from = paste0("fixseqin_PB2expVP",i, ".dat"), 
              to = file.path(base_dir,paste0("DATA/fixseqin_PB2expVP",i, "_model.dat")))
}
setwd(oldwd)